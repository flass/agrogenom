# $Id$
#
# BioPerl module for Bio::TreeIO::Decorator::taxonomy
#
# Please direct questions and support issues to <bioperl-l@bioperl.org>
#
# Cared for by Remi Planel <remi.planel@univ-lyon1.fr>
#
# Copyright Remi Planel
#
# You may distribute this module under the same terms as perl itself

# POD documentation - main docs before the code

=head1 NAME

Bio::TreeIO::Decorator::taxonomy - DESCRIPTION of Object

=head1 SYNOPSIS

Give standard usage here

=head1 DESCRIPTION

Describe the object here

=head1 FEEDBACK

=head2 Mailing Lists

User feedback is an integral part of the evolution of this and other
Bioperl modules. Send your comments and suggestions preferably to
the Bioperl mailing list.  Your participation is much appreciated.

  bioperl-l@bioperl.org                  - General discussion
http://bioperl.org/wiki/Mailing_lists  - About the mailing lists

=head2 Support

Please direct usage questions or support issues to the mailing list:

L<bioperl-l@bioperl.org>

rather than to the module maintainer directly. Many experienced and
reponsive experts will be able look at the problem and quickly
address it. Please include a thorough description of the problem
with code and data examples if at all possible.

=head2 Reporting Bugs

Report bugs to the Bioperl bug tracking system to help us keep track
of the bugs and their resolution. Bug reports can be submitted via
the web:

  http://bugzilla.open-bio.org/

=head1 AUTHOR - Remi Planel

Email remi.planel@univ-lyon1.fr

Describe contact details here

=head1 CONTRIBUTORS

Additional contributors names and emails here

=head1 APPENDIX

The rest of the documentation details each of the object methods.
Internal methods are usually preceded with a _

=cut

# Let the code begin...


package Bio::TreeIO::Decorator::taxonomy;
use strict;
use Data::Dumper;

# Object preamble - inherits from Bio::Root::Root

use Bio::Root::Root;


use base qw(Bio::TreeIO::Decorator);

=head2 new

 Title   : new
 Usage   : my $obj = new Bio::TreeIO::Decorator::taxonomy();
 Function: Builds a new Bio::TreeIO::Decorator::taxonomy object
 Returns : an instance of Bio::TreeIO::Decorator::taxonomy
 Args    :

=cut

sub new {
    my ($class,@args) = @_;

    my $self = $class->SUPER::new(@args);
    
    # my ($ranks) = $self->_rearrange([qw(RANKS)],@args);

    # $self->add_rank($self->annotation->get_ranks);
    return $self;
}



=head2 get_ranks

 Title   : get_ranks
 Usage   : @arr = get_ranks()
 Function: Get the list of rank(s) for this object.
 Example : 
 Returns : An array of scalar objects
 Args    : 

=cut

sub get_ranks{
    my $self = shift;
    
    return @{$self->{'_ranks'}} if exists($self->{'_ranks'});
    return ();
    }

=head2 add_rank

 Title   : add_rank
 Usage   : 
 Function: Add one or more rank(s) to this object.
 Example : 
 Returns : 
 Args    : One or more scalar objects.

=cut

sub add_rank{
    my $self = shift;
    
    $self->{'_ranks'} = [] unless exists($self->{'_ranks'});
    push(@{$self->{'_ranks'}}, @_);
    }

=head2 remove_ranks

 Title   : remove_ranks
 Usage   : 
 Function: Remove all ranks for this class.
 Example : 
 Returns : The list of previous ranks as an array of
          scalar objects.
 Args    : 

=cut

sub remove_ranks {
    my $self = shift;
    
    my @arr = $self->get_ranks();
    $self->{'_ranks'} = [];
    return @arr;
}

=head2 construct_node

 Title   : construct_node
 Usage   : 
 Function: 
 Example : 
 Returns : 
 Args    : 

=cut

sub construct_node {
    my ($self, $node, $jsonNode) = @_;
    
    $self->SUPER::construct_node($node, $jsonNode);


    
    
    my $nodeId     = $self->get_node_facade->get_node_id($node);
    my $annotation = $self->annotation->get_annotation();

    $jsonNode->{taxonomy} = $annotation->{$nodeId};
    
    return;
}




1;
