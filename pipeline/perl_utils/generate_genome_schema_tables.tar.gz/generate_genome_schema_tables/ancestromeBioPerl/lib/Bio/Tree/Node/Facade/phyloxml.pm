# $Id$
#
# BioPerl module for Bio::Tree::Node::Facade::phyloxml
#
# Please direct questions and support issues to <bioperl-l@bioperl.org>
#
# Cared for by Remi Planel <remi.planel@univ-lyon1.fr>
#
# Copyright Remi Planel
#
# You may distribute this module under the same terms as perl itself

# POD documentation - main docs before the code

=head1 NAME

Bio::Tree::Node::Facade::phyloxml - DESCRIPTION of Object

=head1 SYNOPSIS

Give standard usage here

=head1 DESCRIPTION

Describe the object here

=head1 FEEDBACK

=head2 Mailing Lists

User feedback is an integral part of the evolution of this and other
Bioperl modules. Send your comments and suggestions preferably to
the Bioperl mailing list.  Your participation is much appreciated.

  bioperl-l@bioperl.org                  - General discussion
http://bioperl.org/wiki/Mailing_lists  - About the mailing lists

=head2 Support

Please direct usage questions or support issues to the mailing list:

L<bioperl-l@bioperl.org>

rather than to the module maintainer directly. Many experienced and
reponsive experts will be able look at the problem and quickly
address it. Please include a thorough description of the problem
with code and data examples if at all possible.

=head2 Reporting Bugs

Report bugs to the Bioperl bug tracking system to help us keep track
of the bugs and their resolution. Bug reports can be submitted via
the web:

  http://bugzilla.open-bio.org/

=head1 AUTHOR - Remi Planel

Email remi.planel@univ-lyon1.fr

Describe contact details here

=head1 CONTRIBUTORS

Additional contributors names and emails here

=head1 APPENDIX

The rest of the documentation details each of the object methods.
Internal methods are usually preceded with a _

=cut

# Let the code begin...


package Bio::Tree::Node::Facade::phyloxml;
use strict;
use Data::Dumper;

# Object preamble - inherits from Bio::Root::Root

use Bio::Root::Root;


use base qw( Bio::Tree::Node::Facade );

=head2 new

 Title   : new
 Usage   : my $obj = new Bio::Tree::Node::Facade::phyloxml();
 Function: Builds a new Bio::Tree::Node::Facade::phyloxml object
 Returns : an instance of Bio::Tree::Node::Facade::phyloxml
 Args    :

=cut

sub new {
    my ($class,@args) = @_;
    
    my $self = $class->SUPER::new(@args);
    return $self;
}


=head2 get_node_id

 Title   : get_node_id
 Usage   : 
 Function: 
 Example : 
 Returns : 
 Args    : 

=cut

sub get_node_id {
    my ($self, $node) = @_;
    
    my $nodeIdAnnotation = (($node->annotation->get_Annotations('node_id'))[0]->get_Annotations)[0];
    if ( defined $nodeIdAnnotation ) {
        my $nodeId = $nodeIdAnnotation->value;
        chomp($nodeId);
        return $nodeId;
    }
    else {
        return 0;
    }
}


=head2 is_transfer_node

 Title   : is_transfer_node
 Usage   : 
 Function: 
 Example : 
 Returns : 
 Args    : 

=cut

sub is_transfer_node {
    my ($self) = @_;
    
    return;
}



=head2 is_duplication_node

 Title   : is_duplication_node
 Usage   : 
 Function: 
 Example : 
 Returns : 
 Args    : 

=cut

sub is_duplication_node {
    my ($self) = @_;
    
    return;
}



=head2 is_speciation_node

 Title   : is_speciation_node
 Usage   : 
 Function: 
 Example : 
 Returns : 
 Args    : 

=cut

sub is_speciation_node{
    my ($self) = @_;
    
    return;
}



=head2 is_loss_node

 Title   : is_loss_node
 Usage   : 
 Function: 
 Example : 
 Returns : 
 Args    : 

=cut

sub is_loss_node{
    my ($self) = @_;
    
    return;
}


=head2 get_transfered_child

 Title   : get_transfered_child
 Usage   : 
 Function: 
 Example : 
 Returns : 
 Args    : 

=cut

sub get_transfered_child{
    my ($self) = @_;
    
    return;
}


=head2 get_taxonomy_code

 Title   : get_taxonomy_code
 Usage   : 
 Function: 
 Example : 
 Returns : 
 Args    : 

=cut

sub get_taxonomy_code {
    my ($self, $node) = @_;

    my $uniprotTaxa;
    my ($annotation_collection) = $node->annotation();
    my @annotations = $annotation_collection->get_nested_Annotations(
        -keys       => ['taxonomy'],
        -recursive => 1,
    );
    @annotations = $annotations[0]->get_Annotations('code')  if @annotations;
    my @values   = $annotations[0]->get_Annotations('_text') if @annotations; 
    $uniprotTaxa = $values[0]->value if @values;
    return $uniprotTaxa;
    
}


=head2 get_node_name

 Title   : get_node_name
 Usage   : 
 Function: 
 Example : 
 Returns : 
 Args    : 

=cut

sub get_node_name {
    my ($self, $node) = @_;
    
    my ($nameAnnotation) = $node->annotation->get_Annotations('name');
    if ( defined $nameAnnotation ) {
        if ( $nameAnnotation->get_Annotations ) {
            my $name = ($nameAnnotation->get_Annotations)[0]->value;
            chomp($name);
            return $name;
        }
        return;
    }
    else {
        return;
    }
}



=head2 get_hogenom_accession

 Title   : get_hogenom_accession
 Usage   : 
 Function: 
 Example : 
 Returns : 
 Args    : 

=cut

sub get_hogenom_accession{
    my ($self, $node) = @_;

    if ( $node->has_sequence) {
        my $seq = $node->sequence->[0];
        if ( defined $seq ) {
            my @accessions = $seq->annotation->get_Annotations('accession');
            if ( @accessions ) {
                
                foreach my $acc ( @accessions ) {
                    my $attr = (
                        (
                            $acc->get_Annotations('_attr')
                        )[0]->get_Annotations(
                            'source'
                        )
                    )[0]->value;
                    
                    if ( $attr eq 'hogenom') {
                        return ($acc->get_Annotations('_text'))[0]->value;
                    }
                }
            }
        }
        else {
            return 0;
        }
        
    }
    return;
}




=head2 get_node_support

 Title   : get_node_support
 Usage   : 
 Function: 
 Example : 
 Returns : 
 Args    : 

=cut

sub get_node_support{
    my ($self, $node) = @_;
    
    my ($annotation) = $node->annotation->get_Annotations('confidence');

    
    
    if ( defined $annotation ) {
        
        my ($text) = $annotation->get_Annotations('_text');
        
        if ( $text ) {
            return $text->value;
            
            return $text->value if $text;
            
        }
        
        # my $attr = (($annotation->get_Annotations('_attr'))[0]->get_Annotations('type'))[0]->value;
        # print STDERR "\n",$attr,"\n";
        
        # if ( $attr eq 'bootstrap') {

        #     print STDERR Dumper $annotation->get_Annotations('_text');
            
            
        #     return ($annotation->get_Annotations('_text'))[0]->value;
        # }
        
        
        # if ($annotation->get_Annotations) {

            

            
        #     print STDERR Dumper (($annotation->get_Annotations)[0]);
        #     print STDERR ($annotation->get_Annotations)[0];
            
        #     return if (!($annotation->get_Annotations)[0]);
            
        #     my $value = ($annotation->get_Annotations)[0]->value;
        #     chomp($value);
        #     return $value;
        # }
    }
    return;
}





1;
