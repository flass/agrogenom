# $Id$
#
# BioPerl module for Bio::Tree::Annotation
#
# Please direct questions and support issues to <bioperl-l@bioperl.org>
#
# Cared for by Remi Planel <remi.planel@univ-lyon1.fr>
#
# Copyright Remi Planel
#
# You may distribute this module under the same terms as perl itself

# POD documentation - main docs before the code

=head1 NAME

Bio::Tree::Annotation - DESCRIPTION of Object

=head1 SYNOPSIS

Give standard usage here

=head1 DESCRIPTION

Describe the object here

=head1 FEEDBACK

=head2 Mailing Lists

User feedback is an integral part of the evolution of this and other
Bioperl modules. Send your comments and suggestions preferably to
the Bioperl mailing list.  Your participation is much appreciated.

  bioperl-l@bioperl.org                  - General discussion
http://bioperl.org/wiki/Mailing_lists  - About the mailing lists

=head2 Support

Please direct usage questions or support issues to the mailing list:

L<bioperl-l@bioperl.org>

rather than to the module maintainer directly. Many experienced and
reponsive experts will be able look at the problem and quickly
address it. Please include a thorough description of the problem
with code and data examples if at all possible.

=head2 Reporting Bugs

Report bugs to the Bioperl bug tracking system to help us keep track
of the bugs and their resolution. Bug reports can be submitted via
the web:

  http://bugzilla.open-bio.org/

=head1 AUTHOR - Remi Planel

Email remi.planel@univ-lyon1.fr

Describe contact details here

=head1 CONTRIBUTORS

Additional contributors names and emails here

=head1 APPENDIX

The rest of the documentation details each of the object methods.
Internal methods are usually preceded with a _

=cut

# Let the code begin...


package Bio::Tree::Annotation;
use strict;

# Object preamble - inherits from Bio::Root::Root

use Bio::Root::Root;


use base qw(Bio::Root::Root );

=head2 new

 Title   : new
 Usage   : my $obj = new Bio::Tree::Annotation();
 Function: Builds a new Bio::Tree::Annotation object
 Returns : an instance of Bio::Tree::Annotation
 Args    :

=cut

sub new {
    my ($class,@args) = @_;
    
    my $self = $class->SUPER::new(@args);
    
    my ($nodeFacade) = $class->_rearrange([qw(NODE_FACADE)], @args);

    $self->_set_node_facade($nodeFacade);
    
    
    
    return $self;
}


=head2 _set_node_facade()

 Title   : _set_node_facade
 Usage   : $obj->_set_node_facade($newvalue)
 Function: 
 Example : 
 Returns : undef
 Args    : new value (a scalar)

=cut

sub _set_node_facade {
    my ($self, $node_facade) = @_;
    
    $self->{_node_facade} = $node_facade;
    return;
}


=head2 get_node_facade()

 Title   : get_node_facade
 Usage   : $obj->get_node_facade()
 Function: 
 Example : 
 Returns : value of node_facade (a scalar)
 Args    : 

=cut

sub get_node_facade {
    my ($self) = @_;
    
    return $self->{_node_facade};
}



=head2 retrieveAnnotation

 Title   : retrieveAnnotation
 Usage   : 
 Function: 
 Example : 
 Returns : 
 Args    : 

=cut

sub retrieveAnnotation {
    my ($self) = @_;
    
    $self->throw_not_implemented();
}



=head2 get_annotation()

 Title   : get_annotation
 Usage   : $obj->get_annotation()
 Function: 
 Example : 
 Returns : value of annotation (a scalar)
 Args    : 

=cut

sub get_annotation {
    my ($self) = @_;
    
    return $self->{annotation};
}



=head2 set_annotation()

 Title   : set_annotation
 Usage   : $obj->set_annotation($newvalue)
 Function: 
 Example : 
 Returns : undef
 Args    : new value (a scalar)

=cut

sub set_annotation {
    my ($self, $annotation) = @_;
    
    $self->{annotation} = $annotation;
    return;
}


=head2 clean_annotation

 Title   : clean_annotation
 Usage   : 
 Function: 
 Example : 
 Returns : 
 Args    : 

=cut

sub clean_annotation {
    my ($self) = @_;
    $self->{annotation} = undef;
}




1;
