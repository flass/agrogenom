# $Id$
#
# BioPerl module for Bio::Tree::Annotation::Database::dbXref
#
# Please direct questions and support issues to <bioperl-l@bioperl.org>
#
# Cared for by Remi Planel <remi.planel@univ-lyon1.fr>
#
# Copyright Remi Planel
#
# You may distribute this module under the same terms as perl itself

# POD documentation - main docs before the code

=head1 NAME

Bio::Tree::Annotation::Database::dbXref - DESCRIPTION of Object

=head1 SYNOPSIS

Give standard usage here

=head1 DESCRIPTION

Describe the object here

=head1 FEEDBACK

=head2 Mailing Lists

User feedback is an integral part of the evolution of this and other
Bioperl modules. Send your comments and suggestions preferably to
the Bioperl mailing list.  Your participation is much appreciated.

  bioperl-l@bioperl.org                  - General discussion
http://bioperl.org/wiki/Mailing_lists  - About the mailing lists

=head2 Support

Please direct usage questions or support issues to the mailing list:

L<bioperl-l@bioperl.org>

rather than to the module maintainer directly. Many experienced and
reponsive experts will be able look at the problem and quickly
address it. Please include a thorough description of the problem
with code and data examples if at all possible.

=head2 Reporting Bugs

Report bugs to the Bioperl bug tracking system to help us keep track
of the bugs and their resolution. Bug reports can be submitted via
the web:

  http://bugzilla.open-bio.org/

=head1 AUTHOR - Remi Planel

Email remi.planel@univ-lyon1.fr

Describe contact details here

=head1 CONTRIBUTORS

Additional contributors names and emails here

=head1 APPENDIX

The rest of the documentation details each of the object methods.
Internal methods are usually preceded with a _

=cut

# Let the code begin...


package Bio::Tree::Annotation::Database::dbXref;
use strict;
use Data::Dumper;


# Object preamble - inherits from Bio::Root::Root

use Bio::Root::Root;


use base qw(Bio::Tree::Annotation::Database);

# $ENV{DBIC_TRACE} = 1;
=head2 new

 Title   : new
 Usage   : my $obj = new Bio::Tree::Annotation::Database::dbXref();
 Function: Builds a new Bio::Tree::Annotation::Database::dbXref object
 Returns : an instance of Bio::Tree::Annotation::Database::dbXref
 Args    :

=cut

sub new {
    my ($class,@args) = @_;
    
    my $self = $class->SUPER::new(@args);
    return $self;
}



=head2 retrieveAnnotation

 Title   : retrieveAnnotation
 Usage   : 
 Function: 
 Example : 
 Returns : 
 Args    : 

=cut

sub retrieveAnnotation {
    my ($self, $tree) = @_;
    
    my $annotation;
    my $hogenomGeneId_nodeId;
    my $hogenomGeneIdsWhereClause;
    my $prot_rs;
    my $prot_ids_condition;
    my $prot_ids_to_node_id;
    
    $self->set_annotation(undef);
    
    ## loop through the nodes to get the where clauses
    ## and a dictionnary that convert hogenom_gene_id to node_id

    foreach my $node ( $tree->get_nodes ) {

        next if !$node->is_Leaf;
        
        
        my $hogenomGeneId = $self->get_node_facade->get_hogenom_accession($node);
        my $nodeId = $self->get_node_facade->get_node_id($node);

        
        
        if ( defined $hogenomGeneId) {

            $hogenomGeneId =~ s/\./_/g;
            # $hogenomGeneId =~ s/_([^_]+)$/\.$1/g;
            $hogenomGeneId_nodeId->{$hogenomGeneId} = $nodeId;
            push(@$hogenomGeneIdsWhereClause,{hogenom_protein_id => $hogenomGeneId});
        }
    }


    
    # print STDERR Dumper $hogenomGeneIdsWhereClause,"\n";
    
    ## query the database in order to get the db_xref for each
    ## genes in the tree.
    # 1. get the protein_id
    # (tried with a big prefetch but got this error message :
    # DBIx::Class::ResultSource::RowParser::_resolve_collapse():
    # Unable to calculate a definitive collapse column set for ProteinXref
    # (last member of the Protein -> protein_xrefs chain):
    # fetch more unique non-nullable columns
    # may be because that for different protein_id,
    # will have the same protein_xref.db_id and protein_xref.accession.

    
    $prot_rs = $self->get_db_schema->resultset('Protein')->search(
        $hogenomGeneIdsWhereClause
    );
    
    while ( my $prot = $prot_rs->next) {
        my $prot_id = $prot->protein_id;
        
        push(@$prot_ids_condition, {'protein_id' => $prot_id});
        $prot_ids_to_node_id->{$prot_id} =
            $hogenomGeneId_nodeId->{$prot->hogenom_protein_id};

        # print STDERR Dumper $prot_ids_to_node_id->{$prot_id};
        
        
    }
    
    
    
    my $prot_dbxref_rs = $self->get_db_schema->resultset('ProteinXref')->search(
        $prot_ids_condition,
        {
            prefetch => 'db'
        }
    );
    
    while ( my $prot_dbxref = $prot_dbxref_rs->next) {

        

        
        my $nodeId = $prot_ids_to_node_id->{$prot_dbxref->protein_id};
        my $dbname = $prot_dbxref->db->name;
        my $xref_acc = $prot_dbxref->accession;
        my $uri      = $prot_dbxref->db->uri;

        $dbname =~ s/\//_/g;
        
        
        
        # print STDERR $dbname, ' | ',$prot_dbxref->protein_id," | ",$prot_dbxref->accession,"\n";

        # Init if first

        $annotation->{$nodeId}->{$dbname} = [] if !exists $annotation->{$nodeId}->{$dbname};
        
        if (defined $uri) {
            $uri .=  $xref_acc;
        }
        else {
           $uri = ''; 
        }
        
        
        
        push(
            @{$annotation->{$nodeId}->{$dbname}},
            {
                accession => $xref_acc,
                uri       => $uri
            }
        );
    }
    $self->set_annotation($annotation);
    # print STDERR Dumper $annotation;
    
    return;
    

    
}



1;
