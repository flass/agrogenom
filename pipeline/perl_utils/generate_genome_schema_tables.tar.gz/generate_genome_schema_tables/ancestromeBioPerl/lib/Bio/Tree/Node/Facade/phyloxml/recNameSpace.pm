# $Id$
#
# BioPerl module for Bio::Tree::Node::Facade::phyloxml::recNameSpace
#
# Please direct questions and support issues to <bioperl-l@bioperl.org>
#
# Cared for by Remi Planel <remi.planel@univ-lyon1.fr>
#
# Copyright Remi Planel
#
# You may distribute this module under the same terms as perl itself

# POD documentation - main docs before the code

=head1 NAME

Bio::Tree::Node::Facade::phyloxml::recNameSpace - DESCRIPTION of Object

=head1 SYNOPSIS

Give standard usage here

=head1 DESCRIPTION

Describe the object here

=head1 FEEDBACK

=head2 Mailing Lists

User feedback is an integral part of the evolution of this and other
Bioperl modules. Send your comments and suggestions preferably to
the Bioperl mailing list.  Your participation is much appreciated.

  bioperl-l@bioperl.org                  - General discussion
http://bioperl.org/wiki/Mailing_lists  - About the mailing lists

=head2 Support

Please direct usage questions or support issues to the mailing list:

L<bioperl-l@bioperl.org>

rather than to the module maintainer directly. Many experienced and
reponsive experts will be able look at the problem and quickly
address it. Please include a thorough description of the problem
with code and data examples if at all possible.

=head2 Reporting Bugs

Report bugs to the Bioperl bug tracking system to help us keep track
of the bugs and their resolution. Bug reports can be submitted via
the web:

  http://bugzilla.open-bio.org/

=head1 AUTHOR - Remi Planel

Email remi.planel@univ-lyon1.fr

Describe contact details here

=head1 CONTRIBUTORS

Additional contributors names and emails here

=head1 APPENDIX

The rest of the documentation details each of the object methods.
Internal methods are usually preceded with a _

=cut

# Let the code begin...


package Bio::Tree::Node::Facade::phyloxml::recNameSpace;
use strict;

# Object preamble - inherits from Bio::Root::Root

use Bio::Root::Root;


use base qw(Bio::Tree::Node::Facade::phyloxml);
            

=head2 new

 Title   : new
 Usage   : my $obj = new Bio::Tree::Node::Facade::phyloxml::recNameSpace();
 Function: Builds a new Bio::Tree::Node::Facade::phyloxml::recNameSpace object
 Returns : an instance of Bio::Tree::Node::Facade::phyloxml::recNameSpace
 Args    :

=cut

sub new {
    my ($class,@args) = @_;
    
    my $self = $class->SUPER::new(@args);
    return $self;
}



=head2 getEvent

 Title   : getEvent
 Usage   : 
 Function: 
 Example : 
 Returns : 
 Args    : 

=cut

sub getEvent {
    my ($self,$node) = @_;
        
    my @rec_events = $node->annotation->get_Annotations('rec:event');
    my $rec_event = $rec_events[0];
    
    if ( $rec_event ) {
        return $rec_event;
    }
    return;
    
}







=head2 is_transfer_node

 Title   : is_transfer_node
 Usage   : 
 Function: 
 Example : 
 Returns : 
 Args    : 

=cut

sub is_transfer_node {
    my ($self,$node) = @_;

    my $rec_event = $self->getEvent($node);
    if ( $rec_event ) {
        my @rec_event = $rec_event->get_all_annotation_keys;
        if ( grep {$_ eq 'rec:transfer'} @rec_event) {
            return 1;
        } 
    }
    return 0;
}

=head2 is_transfer_annotation

 Title   : is_transfer_annotation
 Usage   : 
 Function: 
 Example : 
 Returns : 
 Args    : 

=cut

sub is_transfer_annotation{
    my ($self, $anno) = @_;
    return 1 if $anno->tagname eq 'rec:transfer';
    return 0;
}



=head2 get_transfer_event

 Title   : get_transfer_event
 Usage   : 
 Function: 
 Example : 
 Returns : 
 Args    : 

=cut

sub get_transfer_event {
    my ($self, $node) = @_;
    
    my $rec_event = $self->getEvent($node);
    if ( $rec_event ) {
        my ($rec_transfer) = $rec_event->get_Annotations('rec:transfer');
        return $rec_transfer;
    }
    return;
}


=head2 is_duplication_node

 Title   : is_duplication_node
 Usage   : 
 Function: 
 Example : 
 Returns : 
 Args    : 

=cut

sub is_duplication_node {
    my ($self,$node) = @_;
    
    my $rec_event = $self->getEvent($node);
    if ( $rec_event ) {
        my @rec_event =  $rec_event->get_all_annotation_keys;
        if ( grep {$_ eq 'rec:duplication'} @rec_event) {
            return 1;
        }
    }
    return 0;
}


=head2 is_duplication_annotation

 Title   : is_duplication_annotation
 Usage   : 
 Function: 
 Example : 
 Returns : 
 Args    : 

=cut

sub is_duplication_annotation{
    my ($self, $anno) = @_;
    return 1 if $anno->tagname eq 'rec:duplication';
    return 0;
}





=head2 get_duplication_event

 Title   : get_duplication_event
 Usage   : 
 Function: 
 Example : 
 Returns : 
 Args    : 

=cut

sub get_duplication_event {
    my ($self, $node) = @_;
    
    my $rec_event = $self->getEvent($node);
    if ( $rec_event ) {
        my ($rec_duplication) = $rec_event->get_Annotations('rec:duplication');
        return $rec_duplication;
    }
    return;
}


=head2 is_speciation_node

 Title   : is_speciation_node
 Usage   : 
 Function: 
 Example : 
 Returns : 
 Args    : 

=cut

sub is_speciation_node {
    my ($self, $node) = @_;
    my $rec_event = $self->getEvent($node);
    if ( $rec_event ) {
        my @rec_event = $rec_event->get_all_annotation_keys;
        if ( grep {$_ eq 'rec:speciation'} @rec_event) {
            return 1;
        } 
    }
    return 0;
}



=head2 is_speciation_key

 Title   : is_speciation_key
 Usage   : 
 Function: 
 Example : 
 Returns : 
 Args    : 

=cut

sub is_speciation_annotation {
    my ($self, $anno) = @_;
    return 1 if $anno->tagname eq 'rec:speciation';
    return 0;
    
}





=head2 get_speciation_event

 Title   : get_speciation_event
 Usage   : 
 Function: 
 Example : 
 Returns : 
 Args    : 

=cut

sub get_speciation_event {
    my ($self, $node) = @_;
    my $rec_event = $self->getEvent($node);
    if ( $rec_event ) {
        my ($rec_speciation) = $rec_event->get_Annotations('rec:speciation');
        return $rec_speciation;
    }
    return;
}


=head2 is_gain_node

 Title   : is_gain_node
 Usage   : 
 Function: 
 Example : 
 Returns : 
 Args    : 

=cut

sub is_gain_node {
    my ($self, $node) = @_;
    my $rec_event = $self->getEvent($node);
    if ( $rec_event ) {
        my @rec_event = $rec_event->get_all_annotation_keys;
        if ( grep {$_ eq 'rec:gain'} @rec_event) {
            return 1;
        } 
    }
    return 0;
}


=head2 get_gain_event

 Title   : get_gain_event
 Usage   : 
 Function: 
 Example : 
 Returns : 
 Args    : 

=cut

sub get_gain_event {
    my ($self, $node) = @_;
    my $rec_event = $self->getEvent($node);
    if ( $rec_event ) {
        my ($rec_gain) = $rec_event->get_Annotations('rec:gain');
        return $rec_gain;
    }
    return;
}

=head2 is_gain_annotation

 Title   : is_gain_annotation
 Usage   : 
 Function: 
 Example : 
 Returns : 
 Args    : 

=cut

sub is_gain_annotation {
    my ($self, $anno) = @_;
    return 1 if $anno->tagname eq 'rec:gain';
    return 0;
    
}



=head2 is_loss_node

 Title   : is_loss_node
 Usage   : 
 Function: 
 Example : 
 Returns : 
 Args    : 

=cut

sub is_loss_node{
    my ($self,$node) = @_;

    my $rec_event = $self->getEvent($node);
    if ( $rec_event ) {
        my @rec_event_anno = $rec_event->get_all_annotation_keys;
        map {return 1 if $_ eq 'rec:loss'}
            @rec_event_anno;
    }
    return 0;
}




=head2 is_loss_annotation

 Title   : is_loss_annotation
 Usage   : 
 Function: 
 Example : 
 Returns : 
 Args    : 

=cut

sub is_loss_annotation{
    my ($self, $anno) = @_;
    return 1 if $anno->tagname eq 'rec:loss';
    return 0;
}





=head2 get_transfered_child

 Title   : get_transfered_child
 Usage   : 
 Function: 
 Example : 
 Returns : 
 Args    : 

=cut

sub get_transfered_child {
    my ($self, $node) = @_;
    
    my $transfer_anno = $self->get_transfer_event($node);
    if ( $transfer_anno ) {
        my ($transferedChild) = $transfer_anno->get_Annotations('rec:transferedChild');
        if ( $transferedChild) {
            my ($value) = $transferedChild->get_Annotations('_text');
            return $value->value if $value;
            return 0;
        }
    }
    
    return;
}



=head2 get_transfer_origin_sp

 Title   : get_transfer_origin_sp
 Usage   : 
 Function: 
 Example : 
 Returns : 
 Args    : 

=cut

sub get_transfer_origin_sp {
    my ($self, $anno) = @_;
    
    if ( $anno ) {
        my ($originSp) = $anno->get_Annotations('rec:originSp');
        if ( $originSp ) {
            my ($value) = $originSp->get_Annotations('_text');
            return $value->value if $value;
            return 0;
        }
    }
}

=head2 get_transfer_recipient_sp

 Title   : get_transfer_recipient_sp
 Usage   : 
 Function: 
 Example : 
 Returns : 
 Args    : 

=cut

sub get_transfer_recipient_sp{
    my ($self, $anno) = @_;
    if ( $anno ) {
        my ($recipientSp) = $anno->get_Annotations('rec:recipientSp');
        if ( $recipientSp ) {
            my ($value) = $recipientSp->get_Annotations('_text');
            return $value->value if $value;
            return 0;
        }
    }
}






=head2 get_node_name

 Title   : get_node_name
 Usage   : 
 Function: 
 Example : 
 Returns : 
 Args    : 

=cut

# sub get_node_name {
#     my ($self, $node) = @_;

#     my ($annotation_collection) = $node->annotation();
#     my @annotations = $annotation_collection->get_nested_Annotations(
#         -keys       => ['taxonomy'],
#         -recursive => 1,
#     );
    
#     @annotations = $annotations[0]->get_Annotations('code')  if @annotations;
#     my @values   = $annotations[0]->get_Annotations('_text') if @annotations; 
#     return $values[0]->value if @values;
#     return;
# }



=head2 get_event_id

 Title   : get_event_id
 Usage   : 
 Function: 
 Example : 
 Returns : 
 Args    : 

=cut

sub get_event_id {
    my ($self, $node) = @_;
    my $rec_event = $self->getEvent($node);

 SWITCH:
    {
        if ( $self->is_transfer_node($node) ) {
            my $transfer_event = $self->get_transfer_event($node);
            if ( $transfer_event ) {
                my ($eventId) = $transfer_event->get_Annotations('rec:event_id');
                if ( $eventId ) {
                    my ($value) = $eventId->get_Annotations('_text');
                    return $value->value if $value;
                    return;
                }
            }
            
            last SWITCH;
        }
        
        if ( $self->is_duplication_node($node) ) {
            my $duplication_event = $self->get_duplication_event($node);
            if ( $duplication_event ) {
                my ($eventId) = $duplication_event->get_Annotations('rec:event_id');
                if ( $eventId ) {
                    my ($value) = $eventId->get_Annotations('_text');
                    return $value->value if $value;
                    return;
                }
                last SWITCH;
            }
        }

        if ( $self->is_speciation_node($node) ) {
            my $speciation_event = $self->get_speciation_event($node);
            if ( $speciation_event ) {
                my ($eventId) = $speciation_event->get_Annotations('rec:event_id');
                if ( $eventId ) {
                    my ($value) = $eventId->get_Annotations('_text');
                    return $value->value if $value;
                    return;
                }
                last SWITCH;
            }
        }


        if ( $self->is_gain_node($node) ) {
            my $gain_event = $self->get_gain_event($node);
            if ( $gain_event ) {
                my ($eventId) = $gain_event->get_Annotations('rec:event_id');
                if ( $eventId ) {
                    my ($value) = $eventId->get_Annotations('_text');
                    return $value->value if $value;
                    return;
                }
                last SWITCH;
            }
        }
        

        
    }
    return;
}


=head2 get_taxid

 Title   : get_taxid
 Usage   : 
 Function: 
 Example : 
 Returns : 
 Args    : 

=cut

sub get_taxid{
    my ($self, $node) = @_;

    my $taxid;
    my $taxonomy = ($node->annotation->get_Annotations('taxonomy'))[0];
    
    if ( defined $taxonomy) {
        my $id = ($taxonomy->get_Annotations('id'))[0];
        return ($id->get_Annotations('_text'))[0]->value;
        if ( defined $id) {
            my $attr = (($id->get_Annotations('_attr'))[0]->get_Annotations('provider'))[0]->value;
            if ( $attr eq 'ncbi') {
                return ($id->get_Annotations('_text'))[0]->value;
            }
        }
    }
    
    return;
    
}


=head2 get_event_string

 Title   : get_event_string
 Usage   : 
 Function: 
 Example : 
 Returns : 
 Args    : 

=cut

sub get_event_string{
    my ($self, $node) = @_;
    return;
}




=head2 get_hogenom_gene_id

 Title   : get_hogenom_gene_id
 Usage   : 
 Function: 
 Example : 
 Returns : 
 Args    : 

=cut

sub get_hogenom_gene_id {
    my ($self, $node) = @_;

    if ( $node->has_sequence) {
        my $seq = $node->sequence->[0];
        if ( defined $seq ) {
            
            my @accessions = $seq->annotation->get_Annotations('accession');
            if ( @accessions ) {
                
                foreach my $acc ( @accessions ) {
                    my $attr = (($acc->get_Annotations('_attr'))[0]->get_Annotations('source'))[0]->value;
                    if ( $attr eq 'hogenom') {
                        return ($acc->get_Annotations('_text'))[0]->value;
                    }
                }
            }
        } else {
            return 0;
        }
        
    }
    # else {
    #     return $self->SUPER::get_node_name($node);
    
    # }
    return;
}


sub createTransferAnnotation {
    my ($self, $node) = @_;
    
    my $transferedChild = $self->get_transfered_child($node);
    my $transferEvent = {
        type => 'transfer',
        transferLink => {
            direction => 'parent'
        } 
    };
    return  $transferEvent;
        
}


1;
