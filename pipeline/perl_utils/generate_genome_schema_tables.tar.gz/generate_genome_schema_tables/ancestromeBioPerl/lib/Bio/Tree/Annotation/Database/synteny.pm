# $Id$
#
# BioPerl module for Bio::Tree::Annotation::Database::synteny
#
# Please direct questions and support issues to <bioperl-l@bioperl.org>
#
# Cared for by Remi Planel <remi.planel@univ-lyon1.fr>
#
# Copyright Remi Planel
#
# You may distribute this module under the same terms as perl itself

# POD documentation - main docs before the code

=head1 NAME

Bio::Tree::Annotation::Database::synteny - DESCRIPTION of Object

=head1 SYNOPSIS

Give standard usage here

=head1 DESCRIPTION

Describe the object here

=head1 FEEDBACK

=head2 Mailing Lists

User feedback is an integral part of the evolution of this and other
Bioperl modules. Send your comments and suggestions preferably to
the Bioperl mailing list.  Your participation is much appreciated.

  bioperl-l@bioperl.org                  - General discussion
http://bioperl.org/wiki/Mailing_lists  - About the mailing lists

=head2 Support

Please direct usage questions or support issues to the mailing list:

L<bioperl-l@bioperl.org>

rather than to the module maintainer directly. Many experienced and
reponsive experts will be able look at the problem and quickly
address it. Please include a thorough description of the problem
with code and data examples if at all possible.

=head2 Reporting Bugs

Report bugs to the Bioperl bug tracking system to help us keep track
of the bugs and their resolution. Bug reports can be submitted via
the web:

  http://bugzilla.open-bio.org/

=head1 AUTHOR - Remi Planel

Email remi.planel@univ-lyon1.fr

Describe contact details here

=head1 CONTRIBUTORS

Additional contributors names and emails here

=head1 APPENDIX

The rest of the documentation details each of the object methods.
Internal methods are usually preceded with a _

=cut

# Let the code begin...


package Bio::Tree::Annotation::Database::synteny;
use strict;
use Data::Dumper;
use JSON;

# Object preamble - inherits from Bio::Root::Root

use Bio::Root::Root;


use base qw(Bio::Tree::Annotation::Database);

=head2 new

 Title   : new
 Usage   : my $obj = new Bio::Tree::Annotation::Database::synteny();
 Function: Builds a new Bio::Tree::Annotation::Database::synteny object
 Returns : an instance of Bio::Tree::Annotation::Database::synteny
 Args    :

=cut

sub new {
    my ($class,@args) = @_;
    
    my $self = $class->SUPER::new(@args);
    
    my ($block, $nbAdjacent) = $self->_rearrange([qw(BLOCK NB_ADJACENT)],@args);
    
    $self->set_nb_adjacent($nbAdjacent);

    $self->_set_block_flag($block || 0);
    
    return $self;
}


=head2 set_nb_adjacent()

 Title   : set_nb_adjacent
 Usage   : $obj->set_nb_adjacent($newvalue)
 Function: 
 Example : 
 Returns : undef
 Args    : new value (a scalar)

=cut

sub set_nb_adjacent {
    my ($self, $nb_adjacent) = @_;
    
    $self->{nb_adjacent} = $nb_adjacent;
    return;
}


=head2 get_nb_adjacent()

 Title   : get_nb_adjacent
 Usage   : $obj->get_nb_adjacent()
 Function: 
 Example : 
 Returns : value of nb_adjacent (a scalar)
 Args    : 

=cut

sub get_nb_adjacent {
    my ($self) = @_;
    
    return $self->{nb_adjacent};
}



=head2 _set_block_flag()

 Title   : _set_block_flag
 Usage   : $obj->_set_block_flag($newvalue)
 Function: 
 Example : 
 Returns : undef
 Args    : new value (a scalar)

=cut

sub _set_block_flag {
    my ($self, $block_flag) = @_;
    $self->{_block_flag} = ($block_flag == 1) ? 1
                                              : 0
                                              ;
    return;
}


=head2 has_block

 Title   : has_block
 Usage   : 
 Function: 
 Example : 
 Returns : 
 Args    : 

=cut

sub has_block {
    my ($self) = @_;
    return $self->{_block_flag};
}





=head2 retrieveAnnotation

 Title   : retrieveAnnotation
 Usage   : 
 Function: 
 Example : 
 Returns : 
 Args    : 

=cut

sub retrieveAnnotation {
    
    my ($self, $tree) = @_;

    $self->set_annotation(undef);
    
    my $nb_adjacent = $self->get_nb_adjacent();
    
    my $annotation = {};
    my $treeFamily = $tree->id();
    my $hogenomGeneId_to_EventId = {};
    my %geneBlocks;
    my $hogGeneId_to_blocks;
    
    if ( $self->has_block) {

        
        ####################################################
        # Associate hogenom_gene_id to ancestral block id. #
        # Generate an hask like :                          #
        # {                                                #
        #     hogenomGeneId => {                           #
        #         ancestralBlockId => treeNodeId,          #
        #     }                                            #
        # }                                                #
        ####################################################

        my @ancBlockIds;
        my $geneTrees = $self->get_db_schema->resultset('GeneTree')->search(
            {
                -and => [
                    'me.family_accession'  => $treeFamily,
                    'anc_block.anc_block_id' => { '!=', 0},
                ],
            },
            {
                prefetch => {
                    'reconciled_gene_trees' => {
                        'events' => {
                            'anc_block' => {
                                'leaf_blocks' => {
                                    'gene2blocks' => 'gene',
                                },
                            },
                        },
                    },
                },
            },
        );
        while ( my $geneTree = $geneTrees->next) {
            ## has_many relation
            ## Join RECONCILED_GENE_TREES
            my $reconciled_gene_trees = $geneTree->reconciled_gene_trees;
            if ( defined $reconciled_gene_trees) {
                while ( my $reconciled_gene_tree = $reconciled_gene_trees->next) {
                    ## has_many relation
                    ## Join EVENTS
                    my $events = $reconciled_gene_tree->events;
                    if ( defined $events) {
                        while ( my $event   = $events->next) {
                            my $event_id    = $event->event_id;
                            my $rec_gi_node = $event->rec_gi_start_node;
                            ## belongs relation
                            my $anc_block   = $event->anc_block;
                            if ( defined $anc_block) {
                                my $anc_block_id = $anc_block->anc_block_id;
                                ## has_many relation
                                my $leaf_blocks = $anc_block->leaf_blocks;
                                if ( defined $leaf_blocks) {
                                    while (my $leaf_block = $leaf_blocks->next) {
                                        my $leaf_block_id = $leaf_block->leaf_block_id;
                                        ## has_many relation
                                        my $gene2blocks = $leaf_block->gene2blocks;
                                        if ( defined $gene2blocks) {
                                            while(my $gene2block = $gene2blocks->next){
                                                my $gene = $gene2block->gene;
                                                $hogGeneId_to_blocks
                                                    ->{$gene->hogenom_gene_id}
                                                    ->{$anc_block_id} = $rec_gi_node;
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }


    
    foreach my $node ( $tree->get_nodes ) {
        my $family4adjacent = [];
        my $unorderedFam4Adj  = {};
        my $node_name = $self->get_node_facade->get_hogenom_gene_id($node);
        my $node_id   = $self->get_node_facade->get_node_id($node);

        
        next if !defined $node_name;
        
        my $hogenom_gene_id;
        my $isProt = 0;
        
        
        # print STDERR $node_name," => ";

        ## test if hogenom_protein_id or hogenom_gene_id.
        ## xxxx_PE1 = protein ; xxxx.PE1 = gene
        
        if ( $node_name !~ /\./) { # this is a protein
            # get the gene_id corresponding.
            my $res = $self->get_db_schema->resultset('Protein')->find(
                {
                    hogenom_protein_id => $node_name
                },
                {
                    key => 'protein_hogenom_protein_id_idx',
                    join => 'gene',
                    '+select' => ['gene.hogenom_gene_id'],
                    '+as'     => ['hogenom_gene_id'],
                        
                }
            );

            if ($res) {
                $hogenom_gene_id = $res->get_column('hogenom_gene_id');
            }
            
            $isProt = 1;
        }
        else {
            $hogenom_gene_id = $node_name;
        }
        
        # print STDERR $hogenom_gene_id,"\n";

        next if (!$hogenom_gene_id);
        
        ## Get the gene_id for this sequences
        
        my $gene_entry =
            $self->get_db_schema->resultset('Gene')->get_gene_from_hogenom_acc(
                $hogenom_gene_id,
            );



        next if (!$gene_entry);
        my $chr_name = $gene_entry->get_column('chromosome');
        ## get the chromosome information for this sequence.
        my $chr_rs = $self->get_db_schema->resultset('Chromosome')->find(
            $chr_name
        );
        


        $annotation->{$node_id}->{adjacents}      = undef;
        $annotation->{$node_id}->{name}           = $node_name;
        $annotation->{$node_id}->{nbAdjRequested} = $self->get_nb_adjacent()*2+1;
        $annotation->{$node_id}->{chromosome}     = {
            name     => $chr_rs->name,
            topology => $chr_rs->topology,
            location => $chr_rs->location,
            length   => $chr_rs->length,
        };
        
        
        ## Get the previous adjacent genes.
        my $previous_adj_gene_id = $self->get_db_schema
            ->resultset('AdjacentPrevious')->get_synteny(
                $gene_entry->gene_id,
                $nb_adjacent,
            );

        pop(@$previous_adj_gene_id);
        
        ## Check if enough adjacent.
        
        ## Suppose to get $nb_adjacent + 1 (the gene on the tree)
        my $lengthPrevious = scalar(@$previous_adj_gene_id);
        
        if ($lengthPrevious < $nb_adjacent) {
            ## will add at the start empty
            my $missing = $nb_adjacent - $lengthPrevious;
            
            for (my $i = 0; $i < $missing; $i++) {
                unshift(@$previous_adj_gene_id,undef);
            }
            
        }
        
        
        
        ## Remove the first gene_id that correspond to the reference gene_id.
        

        ## Get the next adjacent genes.
        my $next_adj_gene_id = $self->get_db_schema
            ->resultset('AdjacentNext')->get_synteny(
                $gene_entry->gene_id,
                $nb_adjacent,
            );

        my $lengthNext = scalar(@$next_adj_gene_id);
        
        if ($lengthNext < $nb_adjacent + 1) {
            ## will add at the start empty
            my $missing = $nb_adjacent + 1 - $lengthNext;
            
            for (my $i = 0; $i < $missing; $i++) {
                push(@$next_adj_gene_id,undef);
            }
            
        }
        
        
        ## Concatenate the 2 arrays.
        push(@$previous_adj_gene_id, @$next_adj_gene_id);

        ## Get the adjacents informations ##
        
        # Generate the where clause for the sql query
        my $adjacent_cond = [ map { {'me.gene_id' => $_} } @$previous_adj_gene_id ];
        
        next if !@$adjacent_cond;
        
        
        my $adjacents = [$self->get_db_schema->resultset('Gene')->search(
            $adjacent_cond,
            {
                prefetch => 'proteins'
            }
        )];

        # print STDERR Dumper $adjacents if $node_id == 20;
        my $adjLength = scalar(@$adjacents);
        
        if ( $adjLength ) {
            
            #Loop through the adjacent genes.
            for ( my $i = 0; $i < $adjLength; $i++) {
                my $adjacent = $adjacents->[$i];
                my $syntenic_gene_info;
                
                if ( defined $adjacent) {

                    my $family_accession = $adjacent->get_column('family_accession');
                    my $geneLength      = $adjacent->genomic_end-$adjacent->genomic_beg;
                    my $hogenom_gene_id_adj = $adjacent->hogenom_gene_id;
                    my $isOnTree        = ($hogenom_gene_id_adj eq $hogenom_gene_id)
                                        ?  JSON::true
                                        :  JSON::false
                                        ;

                    $syntenic_gene_info = {
                        family          => $family_accession,
                        idx             => $i,
                        isOnTree        => $isOnTree,
                        strand          => $adjacent->strand,
                        hogenom_gene_id => $hogenom_gene_id_adj,
                        gene_length     => $geneLength,
                        description     => $adjacent->description || '',
                        name            => $adjacent->name || '',
                        locus_tag       => $adjacent->locus_tag || '',
                        gene_id         => $adjacent->gene_id,
                    };
                    
                    ## has_many relation
                    
                    my $proteins = $adjacent->proteins;
                    my $hogenomProtIds = [];
                    
                    if ( defined $proteins) {
                        while ( my $prot = $proteins->next) {
                            push(@$hogenomProtIds,$prot->hogenom_protein_id);
                        }
                    }
                    $syntenic_gene_info->{hogenom_protein_ids} = $hogenomProtIds; 
                    
                    # print STDERR Dumper $syntenic_gene_info;
                    

                    
                    if ($node_name eq $hogenom_gene_id_adj) {
                        $annotation->{$node_id}->{index_gene_tree} = $i;
                        $syntenic_gene_info->{isOnTree} = JSON::true;       
                    }


                    
                    if ( $self->has_block) {
                        ## Map blocks
                        if ( exists  $hogGeneId_to_blocks->{$hogenom_gene_id_adj} ) {
                            my $geneBlocks = $hogGeneId_to_blocks->{$hogenom_gene_id_adj};
                            
                            ## Associate a gene with the blocks it belongs.
                            my @blockIds = keys%$geneBlocks;
                            $syntenic_gene_info->{blocks} = \@blockIds;
                            
                            ## Map these blocks to the node tree.

                            
                            foreach my $blockId (@blockIds) {
                                my $blocksNodeTree = $geneBlocks->{$blockId};
                                
                                $annotation->{$blocksNodeTree}->{blocks}->{$blockId}++;
                                # = $blocksNodeTree;
                            }
                        }
                    }

                    # save in an hash table because the order is not
                    # always conserved when querying the database.
                    $unorderedFam4Adj->{$adjacent->gene_id} = $syntenic_gene_info;
                }
            }
            
            
            # Not always in the right order after querying the database
            # so do it manually
            foreach my $adjGeneId (@$previous_adj_gene_id) {
                if ($adjGeneId) {
                    push(@$family4adjacent,$unorderedFam4Adj->{$adjGeneId});
                }
                else {
                    push(@$family4adjacent, undef);
                    
                }
                
                
            }
            $annotation->{$node_id}->{adjacents} = $family4adjacent;
        }
    }
    $self->set_annotation($annotation);
    return;
}



1;
