# $Id$
#
# BioPerl module for Bio::Tree::Node::Facade::phyloxml::recNameSpace::agrogenom
#
# Please direct questions and support issues to <bioperl-l@bioperl.org>
#
# Cared for by Remi Planel <remi.planel@univ-lyon1.fr>
#
# Copyright Remi Planel
#
# You may distribute this module under the same terms as perl itself

# POD documentation - main docs before the code

=head1 NAME

Bio::Tree::Node::Facade::phyloxml::recNameSpace::agrogenom - DESCRIPTION of Object

=head1 SYNOPSIS

Give standard usage here

=head1 DESCRIPTION

Describe the object here

=head1 FEEDBACK

=head2 Mailing Lists

User feedback is an integral part of the evolution of this and other
Bioperl modules. Send your comments and suggestions preferably to
the Bioperl mailing list.  Your participation is much appreciated.

  bioperl-l@bioperl.org                  - General discussion
http://bioperl.org/wiki/Mailing_lists  - About the mailing lists

=head2 Support

Please direct usage questions or support issues to the mailing list:

L<bioperl-l@bioperl.org>

rather than to the module maintainer directly. Many experienced and
reponsive experts will be able look at the problem and quickly
address it. Please include a thorough description of the problem
with code and data examples if at all possible.

=head2 Reporting Bugs

Report bugs to the Bioperl bug tracking system to help us keep track
of the bugs and their resolution. Bug reports can be submitted via
the web:

  http://bugzilla.open-bio.org/

=head1 AUTHOR - Remi Planel

Email remi.planel@univ-lyon1.fr

Describe contact details here

=head1 CONTRIBUTORS

Additional contributors names and emails here

=head1 APPENDIX

The rest of the documentation details each of the object methods.
Internal methods are usually preceded with a _

=cut

# Let the code begin...


package Bio::Tree::Node::Facade::phyloxml::recNameSpace::agrogenom;
use strict;

# Object preamble - inherits from Bio::Root::Root

use Bio::Root::Root;


use base qw(Bio::Tree::Node::Facade::phyloxml::recNameSpace);

=head2 new

 Title   : new
 Usage   : my $obj = new Bio::Tree::Node::Facade::phyloxml::recNameSpace::agrogenom();
 Function: Builds a new Bio::Tree::Node::Facade::phyloxml::recNameSpace::agrogenom object
 Returns : an instance of Bio::Tree::Node::Facade::phyloxml::recNameSpace::agrogenom
 Args    :

=cut

sub new {
    my ($class,@args) = @_;
    
    my $self = $class->SUPER::new(@args);
    return $self;
}





=head2 get_species_node_name

 Title   : get_species_node_name
 Usage   : 
 Function: 
 Example : 
 Returns : 
 Args    : 

=cut

sub get_species_node_name {
    my ($self, $node) = @_;

 SWITCH:
    {
        if ( $self->is_speciation_node($node) ) {

            my $spe_event = $self->get_speciation_event($node);
            if ( $spe_event ) {
                my ($species) = $spe_event->get_Annotations('rec:locationSp');
                if ( $species ) {
                    my ($value) = $species->get_Annotations('_text');
                    return $value->value if $value;
                    return 0;
                }
            }
            
            last SWITCH;
        }

        if ( $self->is_transfer_node($node) ) {
            
            my $transfer_event = $self->get_transfer_event($node);
            if ( $transfer_event ) {
                my ($species) = $transfer_event->get_Annotations('rec:originSp');
                if ( $species ) {
                    my ($value) = $species->get_Annotations('_text');
                    return $value->value if $value;
                    return 0;
                }
            }
            last SWITCH;
        }

        if ( $self->is_duplication_node($node) ) {
            
            my $duplication_event = $self->get_duplication_event($node);
            if ( $duplication_event ) {
                my ($species) = $duplication_event->get_Annotations('rec:locationSp');
                if ( $species ) {
                    my ($value) = $species->get_Annotations('_text');
                    return $value->value if $value;
                    return 0;
                }
            }
            last SWITCH;
        }
        
            
        if ( $self->is_gain_node($node) ) {
            
            my $gain_event = $self->get_gain_event($node);
            if ( $gain_event ) {
                my ($species) = $gain_event->get_Annotations('rec:locationSp');
                if ( $species ) {
                    my ($value) = $species->get_Annotations('_text');
                    return $value->value if $value;
                    return 0;
                }
            }
            last SWITCH;
            
        }
        
        
    }
    
    return;
}

=head2 get_event_string

 Title   : get_event_string
 Usage   : 
 Function: 
 Example : 
 Returns : 
 Args    : 

=cut

sub get_event_string{
    # my ($self, $node) = @_;
    return;
}



=head2 get_hogenom_gene_id

 Title   : get_hogenom_gene_id
 Usage   : 
 Function: 
 Example : 
 Returns : 
 Args    : 

=cut

sub get_hogenom_gene_id {
    my ($self, $node) = @_;

    return $self->get_node_name($node);
    
}


=head2 get_hogenom_gene_id

 Title   : get_hogenom_gene_id
 Usage   : 
 Function: 
 Example : 
 Returns : 
 Args    : 

=cut

sub get_hogenom_accession {
    my ($self, $node) = @_;

    return $self->get_node_name($node);
    
}



sub createTransferAnnotation {
    my ($self, $node) = @_;

    my $transferedChild = $self->get_transfered_child($node);
    my $transferEvent = {
        type => 'transfer',
        transferLink => {
            direction => 'child',
            id        => $transferedChild,
        } 
    };
    return  $transferEvent;
        
}



1;
