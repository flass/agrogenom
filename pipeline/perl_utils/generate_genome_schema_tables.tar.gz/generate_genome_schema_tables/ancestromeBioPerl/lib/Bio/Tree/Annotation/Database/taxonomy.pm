# $Id$
#
# BioPerl module for Bio::Tree::Annotation::Database::taxonomy
#
# Please direct questions and support issues to <bioperl-l@bioperl.org>
#
# Cared for by Remi Planle <remi.planel@univ-lyon1.fr>
#
# Copyright Remi Planel
#
# You may distribute this module under the same terms as perl itself

# POD documentation - main docs before the code


=head1 NAME

Bio::Tree::Annotation::Database::taxonomy - DESCRIPTION of Object

=head1 SYNOPSIS

Give standard usage here

=head1 DESCRIPTION

Describe the object here

=head1 FEEDBACK

=head2 Mailing Lists

User feedback is an integral part of the evolution of this and other
Bioperl modules. Send your comments and suggestions preferably to
the Bioperl mailing list.  Your participation is much appreciated.

  bioperl-l@bioperl.org                  - General discussion
http://bioperl.org/wiki/Mailing_lists  - About the mailing lists

=head2 Support

Please direct usage questions or support issues to the mailing list:

L<bioperl-l@bioperl.org>

rather than to the module maintainer directly. Many experienced and
reponsive experts will be able look at the problem and quickly
address it. Please include a thorough description of the problem
with code and data examples if at all possible.

=head2 Reporting Bugs

Report bugs to the Bioperl bug tracking system to help us keep track
of the bugs and their resolution. Bug reports can be submitted via
the web:

  http://bugzilla.open-bio.org/

=head1 AUTHOR - Remi Planle

Email remi.planel@univ-lyon1.fr

Describe contact details here

=head1 CONTRIBUTORS

Additional contributors names and emails here

=head1 APPENDIX

The rest of the documentation details each of the object methods.
Internal methods are usually preceded with a _

=cut

# Let the code begin...


package Bio::Tree::Annotation::Database::taxonomy;
use strict;
use Data::Dumper;


# Object preamble - inherits from Bio::Root::Root

use Bio::Root::Root;


use base qw(Bio::Tree::Annotation::Database);

=head2 new

 Title   : new
 Usage   : my $obj = new Bio::Tree::Annotation::Database::taxonomy();
 Function: Builds a new Bio::Tree::Annotation::Database::taxonomy object
 Returns : an instance of Bio::Tree::Annotation::Database::taxonomy
 Args    :

=cut

sub new {
    my ($class,@args) = @_;
    
    my $self = $class->SUPER::new(@args);
    my ($ranks) = $self->_rearrange([qw(RANKS)], @args);
    
    $self->add_rank(@$ranks);
    
    return $self;

}



=head2 get_ranks

 Title   : get_ranks
 Usage   : @arr = get_ranks()
 Function: Get the list of rank(s) for this object.
 Example : 
 Returns : An array of scalar objects
 Args    : 

=cut

sub get_ranks{
    my $self = shift;
    
    return @{$self->{'_ranks'}} if exists($self->{'_ranks'});
    return ();
}

=head2 add_rank

 Title   : add_rank
 Usage   : 
 Function: Add one or more rank(s) to this object.
 Example : 
 Returns : 
 Args    : One or more scalar objects.

=cut

sub add_rank {
    my $self = shift;
    
    $self->{'_ranks'} = [] unless exists($self->{'_ranks'});
    push(@{$self->{'_ranks'}}, @_);
    
}

=head2 remove_ranks

 Title   : remove_ranks
 Usage   : 
 Function: Remove all ranks for this class.
 Example : 
 Returns : The list of previous ranks as an array of
          scalar objects.
 Args    : 

=cut

sub remove_ranks {
    my $self = shift;
    
    my @arr = $self->get_ranks();
    $self->{'_ranks'} = [];
    return @arr;
}






=head2 retrieveAnnotation

 Title   : retrieveAnnotation
 Usage   : 
 Function: 
 Example : 
 Returns : 
 Args    : 

=cut

sub retrieveAnnotation {
    my ($self, $tree) = @_;
    $self->set_annotation(undef);
    
    # if ( !defined $self->get_annotation) {
    ## Construct hash used to query the DB
    my $speciesNodeIds;
    my $taxIds;
    my $speciesNodeIdsMap;
    my $nodeId_to_speciesNodeId;
    my $speciesNodeId_to_lineage;
    my $spNode_lineage_relation = 'search_tax_2';
    my $annotation = {};

    
    my $taxid_to_taxonomy;
        
    foreach my $rank ( $self->get_ranks ) {
        $annotation->{$rank} = undef;
    }
        
        
    #################################################
    ## Construct the list of species code to query ##
    #################################################

    
    my $nodeIdToTaxid = $self->constructNodeIdToTaxid($tree);
    my @nodeIds       = keys %$nodeIdToTaxid;
    ## Prepare the condition list.
    my $taxidsCondition = [map { {tax_id => $_} } values %$nodeIdToTaxid];


        
    my $taxo_rs = $self->get_db_schema->resultset('Node')->search(
        $taxidsCondition
    );

    while (my $taxo = $taxo_rs->next) {
        my $taxidNode = $taxo->tax_id;
        my $pathStr   = $taxo->path;
        
        $taxid_to_taxonomy->{$taxidNode} =
            $self->getTaxonomyObject($pathStr, $taxo->rank, $taxidNode);
        
    }
    
    foreach my $nodeId ( @nodeIds ) {
        
        my $taxId = $nodeIdToTaxid->{$nodeId};
        
        $annotation->{$nodeId} = $taxid_to_taxonomy->{$taxId};
        
    } 
    ## set internal taxonomy
    
    $self->_setInternalTaxonomy($tree->get_root_node, $annotation);
    $self->set_annotation($annotation);
        
    return;
    # }
}



sub getTaxonomyObject {
    my ($self, $path) = @_;
    

    my $taxoObj;
    $taxoObj->{path_id} = $path;
    # $taxoObj->{tax_id}  = $taxidNode;
    # $taxoObj->{rank}    = $rank;
    
    
    my $taxidsFromPath = [split(/\./,$path)];
    ## get all taxo information for the path taxids
    
    my $names_rs = $self->get_db_schema->resultset('Node')->search(
        {
            "me.tax_id"        => $taxidsFromPath,
            'names.name_class' => 'scientific name'
        },
        {
            join => 'names',
            '+select' => ['names.name_txt'],
            '+as'     => ['name_txt'],
        }
    );
    
    
    my $completeTax = [];
    my $printTaxo;
    my $rankObj;
    
    foreach my $tax ( @$taxidsFromPath) {
        my $taxNames = $names_rs->find({tax_id => $tax});
        my $rank     = $taxNames->rank;
        my $name     = $taxNames->get_column('name_txt');

        $rankObj = {rank => $rank,name => $name,tax_id => $tax};
            
        push(@$completeTax,$rankObj);
        $printTaxo->{$rank} = $name;
    }

    ## Add the strain info

    

    if ( $self->get_db_schema->resultset('Lineageagro') ) {

        my $strain = $self->get_db_schema->resultset('Lineageagro')->find($taxidsFromPath->[-1])->strain_rank;
       
        $printTaxo->{strain} = $strain;
    }
    
    

    $printTaxo->{tax_id}= $rankObj->{tax_id};
    $taxoObj->{lineage} = $completeTax ;
    $taxoObj->{print}   = $printTaxo;
    $taxoObj->{rank}    = $rankObj->{rank};
    $taxoObj->{name}    = $rankObj->{name};
    
    return $taxoObj;
    
}



sub constructNodeIdToTaxid {
    my ($self, $tree) = @_;

    my $spNameToNodeId;
    my $nodeIdToTaxid;
    my $speciesNameMap;
    

    my @nodes = $tree->get_nodes;
    
    
    foreach my $node ( @nodes ) {
        my $speciesName = $self->get_node_facade->get_species_node_name($node);
        my $nodeId        = $self->get_node_facade->get_node_id($node);


        
        
        if ( defined $speciesName) {
            $speciesName =~ s/\'//g;
            my $node_id = $self->get_node_facade->get_node_id($node);
            
            # For a spName it can have several nodeId.
            if ( exists $spNameToNodeId->{$speciesName}) {
                push(@{$spNameToNodeId->{$speciesName}},$node_id);
            } else {
                $spNameToNodeId->{$speciesName} = [$node_id];
            }
        }
    }


    
    ## Prepare the condition list.
    my $speciesNames = [
        map {$_ = {number => $_}}
            # map {$_ = {sp_node_id => $_}}
            keys %$spNameToNodeId
        ];



    my $spNode_rs = $self->get_db_schema->resultset('SpeciesNode')->search(
        $speciesNames
    );
    
    ## Prepare hash $speciesNodeId_to_lineage
    while (my $spNode = $spNode_rs->next) {
        my $taxId       = $spNode->tax_id;
        my $spName      = $spNode->number;
        my $listNodeIds = $spNameToNodeId->{$spName};
        foreach my $nodeId (@$listNodeIds) {
            $nodeIdToTaxid->{$nodeId} = $taxId;
        }
    }
    return $nodeIdToTaxid;
    
}

sub _setInternalTaxonomy {
    my ($self, $node, $annotation, $rank) = @_;
    
    my $node_id = $self->get_node_facade->get_node_id($node);
    my $pathId  = $annotation->{$node_id}->{path_id};
    
    
    if ( defined $pathId && $pathId ne '') {
        return $pathId;
    }
    
    my @pathIds;
    
    foreach my $childNode ( $node->each_Descendent() ) {
        my $childPathId = $self->_setInternalTaxonomy(
            $childNode,
            $annotation,
            $rank
        );
        
        push(@pathIds,$childPathId) if (defined $childPathId &&  $childPathId ne '');
    }


    ## construct consensus path

    my @arrayPathIds    = map {[split(/\./)]} @pathIds;
    my $arrayPathIdsL   = scalar(@arrayPathIds);
    my $refPathId       = $arrayPathIds[0];
    my $refPathIdL = ($refPathId) ? scalar(@$refPathId) : 0;
    my @pathIdConsensus;
    my $pathIdConsensus = '';

    PATH_CONS : for (my $iRef = 0; $iRef < $refPathIdL; $iRef++) {
        my $taxid = $refPathId->[$iRef];
        for (my $iListPaths = 1; $iListPaths < $arrayPathIdsL; $iListPaths++) {
            my $pathIdCheck = $arrayPathIds[$iListPaths]->[$iRef];
            if ( !defined $pathIdCheck || $taxid != $pathIdCheck) {
                last PATH_CONS;
            }
        }
        push(@pathIdConsensus,$taxid);
    }

    $pathIdConsensus = join('.',@pathIdConsensus);
    
    $annotation->{$node_id} = $self->getTaxonomyObject($pathIdConsensus);
    
    return $annotation->{$node_id}->{path_id};
    
}


=head2 setInternalTaxonomy

 Title   : setInternalTaxonomy
 Usage   : 
 Function: 
 Example : 
 Returns : 
 Args    : 

=cut

sub setInternalTaxonomy {
    my ($self, $node, $rank, $annotation) = @_;

    my $node_id   = $self->get_node_facade->get_node_id($node);
    my $rankValue = $annotation->{$node_id}->{$rank};
    
    if ( defined $rankValue && $rankValue ne '') {
        return $rankValue;
    }
    
    my %rankValues;
    
    foreach my $childNode ( $node->each_Descendent() ) {
        my $childRankValue = $self->setInternalTaxonomy(
            $childNode,
            $rank,
            $annotation
        );
        
        $rankValues{$childRankValue}++ if defined $childRankValue;
    }

    ## The childs have the same taxo value
    if ( keys %rankValues == 1 && (values %rankValues)[0] > 1) { 
        my $val = (keys %rankValues)[0];
        $annotation->{$node_id}->{$rank} = $val;
        return $val;
        
    }
    return;
}


1;
