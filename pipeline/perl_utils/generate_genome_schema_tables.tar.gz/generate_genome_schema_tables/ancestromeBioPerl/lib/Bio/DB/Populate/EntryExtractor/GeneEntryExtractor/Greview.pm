# $Id$
#
# BioPerl module for Bio::DB::Populate::EntryExtractor::GeneEntryExtractor::Greview
#
# Please direct questions and support issues to <bioperl-l@bioperl.org>
#
# Cared for by Remi Planel <remi.planel@univ-lyon1.fr>
#
# Copyright Remi Planel
#
# You may distribute this module under the same terms as perl itself

# POD documentation - main docs before the code

=head1 NAME

Bio::DB::Populate::EntryExtractor::GeneEntryExtractor::Greview - DESCRIPTION of Object

=head1 SYNOPSIS

Give standard usage here

=head1 DESCRIPTION

Describe the object here

=head1 FEEDBACK

=head2 Mailing Lists

User feedback is an integral part of the evolution of this and other
Bioperl modules. Send your comments and suggestions preferably to
the Bioperl mailing list.  Your participation is much appreciated.

  bioperl-l@bioperl.org                  - General discussion
http://bioperl.org/wiki/Mailing_lists  - About the mailing lists

=head2 Support

Please direct usage questions or support issues to the mailing list:

L<bioperl-l@bioperl.org>

rather than to the module maintainer directly. Many experienced and
reponsive experts will be able look at the problem and quickly
address it. Please include a thorough description of the problem
with code and data examples if at all possible.

=head2 Reporting Bugs

Report bugs to the Bioperl bug tracking system to help us keep track
of the bugs and their resolution. Bug reports can be submitted via
the web:

  http://bugzilla.open-bio.org/

=head1 AUTHOR - Remi Planel

Email remi.planel@univ-lyon1.fr

Describe contact details here

=head1 CONTRIBUTORS

Additional contributors names and emails here

=head1 APPENDIX

The rest of the documentation details each of the object methods.
Internal methods are usually preceded with a _

=cut

# Let the code begin...


package Bio::DB::Populate::EntryExtractor::GeneEntryExtractor::Greview;
use strict;

# Object preamble - inherits from Bio::Root::Root

use Bio::Root::Root;


use base qw(Bio::DB::Populate::EntryExtractor::GeneEntryExtractor );

=head2 new

 Title   : new
 Usage   : my $obj = new Bio::DB::Populate::EntryExtractor::GeneEntryExtractor::Greview();
 Function: Builds a new Bio::DB::Populate::EntryExtractor::GeneEntryExtractor::Greview object
 Returns : an instance of Bio::DB::Populate::EntryExtractor::GeneEntryExtractor::Greview
 Args    :

=cut

sub new {
    my ($class,@args) = @_;
    
    my $self = $class->SUPER::new(@args);

    $self->set_starting_entry_feat(
        {
            'CDS'    => undef,
        }
    );

    
    return $self;
}


=head2 get_Features

 Title   : get_Features
 Usage   : 
 Function: 
 Example : 
 Returns : 
 Args    : 

=cut

sub get_Features{
    my ($self, $seq) = @_;
    
    ## Loop through feature 'CDS'
    my @features = $seq->get_SeqFeatures('CDS');
    return \@features;
}

=head2 wantProtSeq

 Title   : wantProtSeq
 Usage   : 
 Function: 
 Example : 
 Returns : 
 Args    : 

=cut

sub wantProtSeq {
    my ($self) = @_;
    return 1;
    
}



=head2 add_hogenom_gene_id_to_entry

 Title   : add_hogenom_gene_id_to_entry
 Usage   : 
 Function: 
 Example : 
 Returns : 
 Args    : 

=cut

sub add_hogenom_gene_id_to_entry {
    my ($self, $geneEntry, $entry_features, $CDS_count, $hogGenomeId) = @_;
    
    $self->check_or_fill_hogenom_gene_id(
        $geneEntry,
        ## increment since $CDS_count is the number of written entry
        ## => so +1 for this one
        $CDS_count,
        $hogGenomeId,
        undef,
    );
    return;
}


=head2 add_name_to_entry

 Title   : add_name_to_entry
 Usage   : 
 Function: 
 Example : 
 Returns : 
 Args    : 

=cut

sub add_name_to_entry {
    my ($self, $geneEntry, $entry_features) = @_;
    
    my $gene_name;
    my $geneWriter = $self->get_gene_writer;
    foreach my $primary_tag ( ('CDS') ) {
        if ( defined $entry_features->{$primary_tag} ) {
            my $feat = $entry_features->{$primary_tag};
            
            my $gene_name;
            if (  $feat->has_tag('gene_name') ) {
                $gene_name = ($feat->get_tag_values('gene_name'))[0];
                last;
            }
            
            if (  $feat->has_tag('orf_name') ) {
                $gene_name = ($feat->get_tag_values('orf_name'))[0];
                last;
            }
        }
    }
    
    if ( defined $gene_name) {
        $gene_name = $self->cleanTextEntry($gene_name);
        $geneWriter->setColumnValue(
            $geneEntry,
            'name',
            $gene_name
        );
    }
    else {
        $self->tupleNotFound($geneEntry,'Gene name');
    }
    return;
}






=head2 add_locus_tag_to_entry

 Title   : add_locus_tag_to_entry
 Usage   : 
 Function: 
 Example : 
 Returns : 
 Args    : 

=cut

sub add_locus_tag_to_entry {
    my ($self, $geneEntry, $entry_features) = @_;

    my $geneWriter = $self->get_gene_writer;
    foreach my $primary_tag ( ('CDS') ) {
        if ( defined $entry_features->{$primary_tag} ) {
            my $feat = $entry_features->{$primary_tag};
            my $gene_locus_tag;

            if (  $feat->has_tag('locus_tag') ) {
                $gene_locus_tag = ($feat->get_tag_values('locus_tag'))[0];
                $gene_locus_tag = $self->cleanTextEntry($gene_locus_tag);
                ## Fill the entry with the extracted locus tag
                $geneWriter->setColumnValue(
                    $geneEntry,
                    'locus_tag',
                    $gene_locus_tag
                );
                return;
            }
        }
    }
    ## If here, locus tag not found
    $self->tupleNotFound($geneEntry,'Locus tag');
    return;
}




sub add_description_to_entry {
    my ($self, $geneEntry,$entry_features) = @_;
    
    my $description;
    my $geneWriter = $self->get_gene_writer;
    
    foreach my $primary_tag ( ('CDS') ) {
        if ( defined $entry_features->{$primary_tag} ) {
            my $feat = $entry_features->{$primary_tag};
            
            if (  $feat->has_tag('product') ) {
                $description = ($feat->get_tag_values('product'))[0];
                last;
            }
            
            if (  $feat->has_tag('function') ) {
                $description = join(" ; ",$feat->get_tag_values('function'));
                last;
            }
            
            if (  $feat->has_tag('biological_process') ) {
                $description = join(" ; ",$feat->get_tag_values('biological_process'));
                last;
            }
        }
    }
    
    if ( defined $description) {
        $description = $self->cleanTextEntry($description);
        $geneWriter->setColumnValue(
            $geneEntry,
            'description',
            $description
        );
    }
    else {
        $self->tupleNotFound($geneEntry,'Description');
    }
    return;
}



=head2 extract_chromosome

 Title   : extract_chromosome
 Usage   : 
 Function: 
 Example : 
 Returns : 
 Args    : 

=cut

sub extract_chromosome{
    my ($self, $seq) = @_;

    ## Define genome accession number as chromosome
    my $chromosome = (defined $seq->display_id )
                   ? uc($seq->display_id)
                   : $seq->throw(
                       'No genome accession number for => '.$seq->accession_number
                   );
    $self->set_chromosome($chromosome);
    return $chromosome;
}




1;
