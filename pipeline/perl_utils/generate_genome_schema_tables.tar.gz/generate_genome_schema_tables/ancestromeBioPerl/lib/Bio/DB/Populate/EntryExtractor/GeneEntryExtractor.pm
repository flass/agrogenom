# $Id$
#
# BioPerl module for Bio::DB::Populate::EntryExtractor::GeneEntryExtractor
#
# Please direct questions and support issues to <bioperl-l@bioperl.org>
#
# Cared for by Remi Planel <remi.planel@univ-lyon1.fr>
#
# Copyright Remi Planel
#
# You may distribute this module under the same terms as perl itself

# POD documentation - main docs before the code

=head1 NAME

Bio::DB::Populate::EntryExtractor::GeneEntryExtractor - DESCRIPTION of Object

=head1 SYNOPSIS

Give standard usage here

=head1 DESCRIPTION

Describe the object here

=head1 FEEDBACK

=head2 Mailing Lists

User feedback is an integral part of the evolution of this and other
Bioperl modules. Send your comments and suggestions preferably to
the Bioperl mailing list.  Your participation is much appreciated.

  bioperl-l@bioperl.org                  - General discussion
http://bioperl.org/wiki/Mailing_lists  - About the mailing lists

=head2 Support

Please direct usage questions or support issues to the mailing list:

L<bioperl-l@bioperl.org>

rather than to the module maintainer directly. Many experienced and
reponsive experts will be able look at the problem and quickly
address it. Please include a thorough description of the problem
with code and data examples if at all possible.

=head2 Reporting Bugs

Report bugs to the Bioperl bug tracking system to help us keep track
of the bugs and their resolution. Bug reports can be submitted via
the web:

  http://bugzilla.open-bio.org/

=head1 AUTHOR - Remi Planel

Email remi.planel@univ-lyon1.fr

Describe contact details here

=head1 CONTRIBUTORS

Additional contributors names and emails here

=head1 APPENDIX

The rest of the documentation details each of the object methods.
Internal methods are usually preceded with a _

=cut

# Let the code begin...


package Bio::DB::Populate::EntryExtractor::GeneEntryExtractor;
use strict;
use Data::Dumper;


# Object preamble - inherits from Bio::Root::Root

use Bio::DB::Populate::TableEntryWriter;
use Bio::DB::Populate::EntryExtractor::ProteinEntryExtractor;


use base qw(Bio::DB::Populate::EntryExtractor);

=head2 new

 Title   : new
 Usage   : my $obj = new Bio::DB::Populate::EntryExtractor::GeneEntryExtractor();
 Function: Builds a new Bio::DB::Populate::EntryExtractor::GeneEntryExtractor object
 Returns : an instance of Bio::DB::Populate::EntryExtractor::GeneEntryExtractor
 Args    :

=cut

sub new {
    my ($class,@args) = @_;
    
    my $self = $class->SUPER::new(@args);
    my (
        $protein_idx,
        # $family_type_id,
        $auto_increment_start,
        $output_dir,
        $taxidsToExtract,
    ) = $self->_rearrange(
        [qw(
               PROTEIN_IDX
               AUTO_INCREMENT_START
               OUTPUT
               TAXIDS
       )],
        @args,
    );
    
    ## construct table entry writer
    my $geneTable = Bio::DB::Populate::TableEntryWriter->new(
        -file                 => $output_dir.'/gene_table.csv',
        -column_def           => [
            'gene_id',
            'tax_id',
            'family_accession',
            'name',
            'locus_tag',
            'chromosome',
            'genomic_beg',
            'genomic_end',
            'strand',
            'description',
            'hogenom_gene_id',
        ],
        -auto_increment       => 'gene_id',
        -auto_increment_start => $auto_increment_start,
    );

    $self->set_protein_entry_extractor(
        Bio::DB::Populate::EntryExtractor::ProteinEntryExtractor->new(
            -protein_idx          => $protein_idx,
            -auto_increment_start => 1,
            -output               => $output_dir,
        ),
    );
    
    
    my $geneAdjacentWiter = Bio::DB::Populate::TableEntryWriter->new(
        -file                 => $output_dir.'/gene_adjacent_table.csv',
        -column_def           => [
            'geneIdA',
            'geneIdB',
        ],
    );


    my $chromosomeWriter = Bio::DB::Populate::TableEntryWriter->new(
        -file                 => $output_dir.'/chromosome_table.csv',
        -column_def           => [
            'name',
            'tax_id',
            'topology',
            'location',
            'length'
        ],
    );
    
    $self->set_taxids($taxidsToExtract);
    $self->set_protein_idx($protein_idx);
    $self->set_gene_writer($geneTable);
    $self->set_adjacent_gene_writer($geneAdjacentWiter);
    $self->set_chromosome_writer($chromosomeWriter);
    
    $self->set_cds_count(0);
    return $self;
}



=head2 write_entries

 Title   : write_entries
 Usage   : 
 Function: 
 Example : 
 Returns : 
 Args    : 

=cut

sub write_entries {
    my ($self, $genome) = @_;
    
    
    my %entry_features;
    
    ## Create the chromosome entry.
    my $chromosomeWriter = $self->get_chromosome_writer();
    my $geneWriter       = $self->get_gene_writer();
    my $hogGenomeId      = $genome->display_id;
    my $features         = $self->get_Features($genome);
    ## Record feat that are needed to write a geneTable entry
    my $is_current_entry = 1; 
    my $count_CDS        = 0;
    my $check_count_CDS  = 0;
    my $recording_entry_feat = 0;
    my $previous_gene_id;
    
    
    ## Extract the chromosome tuples from the genome object
    ## and fill the entry with it
    my $chromosomeEntry = $self->fill_chromosome_entry($genome);
    
    ## Test if the current taxid is on the list of the taxid to extract.
    
    # Get the current genome taxid form the chromosome entry.
    my $tax_id = $chromosomeWriter->getColumnValue(
        $chromosomeEntry,
        'tax_id',
    );
    ## test if in the list of wanted taxid
    if (!$self->hasToExtractTaxid($tax_id)) {
        Log::Log4perl->get_logger->info("Skip the taxid : ".$self->get_taxid);
        return 0;
    }
    
    # The taxid is on the list =>  write it
    $chromosomeWriter->writeEntry($chromosomeEntry);
    
    
    #############################
    # Write the gene entry      #
    #############################
    
    
    
    ## init previous_entry and current_entry
    # $self->set_previous_entry( undef );
    # $self->set_current_entry($geneEntry);
    
        
    ## hash that store all the features needed to fill current entry
    $self->set_entry_features(undef);
    
    foreach my $feat ( @$features ) {
        # Log::Log4perl->get_logger->debug($feat->primary_tag);
                
        ## Will split the genome feature in order to identify the genes.
        
        ## Check if this feature is part of the current entry (CDS)
        $is_current_entry = $self->is_feat_current_entry(
            $feat,
            $recording_entry_feat
        );
            
        # print STDERR "$is_current_entry\n";
                        
        ## Change the recording flag depending on the feature.
        ## When recording state is TRUE, the starting_entry_feat
        ## are consider as part of the entry
        ## and not the beginning of a new entry
        ## For example : 1) \CDS , \gene and then \5'ncr.
        ## In this case, \5'ncr is part of the entry that is recording.
        ##               2) \CDS , \5'ncr : means that we started a new entry.
        $recording_entry_feat = $self->check_recording_state(
            $feat,
            $recording_entry_feat
        );
        
        if ( $is_current_entry ) {
            
            ## Record the features that belong to the same CDS
            $self->add_entry_feature($feat,\%entry_features);
            # next;
        }
        else {
            my $geneEntry;
            
            ## Current feature not part of the current CDS
            ## so write entry from the recorded features.
            eval {
                ## Extract from the recorded features
                ## the information to create the new entry
                $geneEntry = $self->fill_gene_entry(
                    \%entry_features,
                    $chromosomeEntry,
                    $count_CDS,
                    $hogGenomeId
                );
            };
            if ( $@ ) {
                $count_CDS = $self->handleErrors($@, $count_CDS);
                undef %entry_features;
                
            }
            else {
                $count_CDS++;
                
                my $current_gene_id = $geneWriter->getColumnValue(
                    $geneEntry,
                    'gene_id',
                );

                my $adjGeneEntry = $self->fill_adjacent_entry(
                    $previous_gene_id,
                    $current_gene_id
                );
                ## save the gene_id of the
                $previous_gene_id = $current_gene_id;

                # print STDERR 'Dans loop previous_gene_id = ',$previous_gene_id,"\n";
                
                
                $self->write_gene_entry($geneEntry);
                $self->write_adjacent_entry($adjGeneEntry);
                undef %entry_features;
                # $self->start_new_entry();
            }
            
            ## Started a new entry so record the feat that
            ## was considered as part of the next entry
            $self->add_entry_feature($feat, \%entry_features);
        }
        

        if ( $feat->primary_tag eq 'CDS') {
            $check_count_CDS++;
        } 
    }

    
    ## if there is features loaded in source, fill current entry with that
    ## if not, means that current already been filled
    if ( %entry_features ) {
        my $geneEntry;
        
        eval {
            $geneEntry = $self->fill_gene_entry(
                \%entry_features,
                $chromosomeEntry,
                $count_CDS,
                $hogGenomeId
            );
        };
        if ( $@ ) {
            $count_CDS = $self->handleErrors($@, $count_CDS);
            undef %entry_features;
        }
        else {
            
            $count_CDS++;
            my $current_gene_id = $geneWriter->getColumnValue(
                $geneEntry,
                'gene_id',
            );
            
            my $adjGeneEntry = $self->fill_adjacent_entry(
                $previous_gene_id,
                $current_gene_id
            );
            ## save the gene_id of the
            $previous_gene_id = $current_gene_id;

            # print STDERR '$previous_gene_id = ',$previous_gene_id,"\n";
            
            $self->write_gene_entry($geneEntry);
            $self->write_adjacent_entry($adjGeneEntry);
            undef %entry_features;
            # $self->start_new_entry();
            
            # $self->write_gene_entry();
            # $self->start_new_entry();
        }
    }
    # $self->write_gene_entry();
    $self->add_cds_count($count_CDS);
    return $count_CDS;
}




=head2 fill_chromosome_entry

 Title   : fill_chromosome_entry
 Usage   : 
 Function: 
 Example : 
 Returns : 
 Args    : 

=cut

sub fill_chromosome_entry {
    my ($self,$genome) = @_;
    
    my $chromosomeWriter = $self->get_chromosome_writer;
    my $chromosomeEntry  = $chromosomeWriter->getNewEntry();
    my $tax_id           = $self->extract_taxid($genome);
    my $chromosome       = $self->extract_chromosome($genome);
    my $location         = $self->extract_location($genome);
    
    $chromosomeWriter->setColumnValue(
        $chromosomeEntry,
        'name',
        $chromosome,
    );
    $chromosomeWriter->setColumnValue(
        $chromosomeEntry,
        'tax_id',
        $tax_id,
    );
    $chromosomeWriter->setColumnValue(
        $chromosomeEntry,
        'topology',
        ($genome->is_circular) ? 'circular': 'linear',
    );
    $chromosomeWriter->setColumnValue(
        $chromosomeEntry,
        'location',
        $location,
    );
    $chromosomeWriter->setColumnValue(
        $chromosomeEntry,
        'length',
        $genome->length,
    );
    
    return $chromosomeEntry;
}



=head2 fill_adjacent_entry

 Title   : fill_adjacent_entry
 Usage   : 
 Function: 
 Example : 
 Returns : 
 Args    : 

=cut

sub fill_adjacent_entry {
    my ($self, $previous, $current) = @_;
    
    my $adjGeneWriter = $self->get_adjacent_gene_writer();
    my $adjGeneEntry  = $adjGeneWriter->getNewEntry();
    
    # print STDERR "Dans fill_adjacent_write\n";
    # print STDERR '$previous = ',$previous,"\ncurrent = ",$current,"\n";
    
    
    if ( defined $previous && defined $current) {
        
        $adjGeneWriter->setColumnValue(
            $adjGeneEntry,
            'geneIdA',
            $previous,
        );
        
        $adjGeneWriter->setColumnValue(
            $adjGeneEntry,
            'geneIdB',
            $current,
        );


        # print STDERR Dumper $adjGeneWriter;
        
        
    }
    
    
    return $adjGeneEntry;
}



=head2 fill_gene_entry

 Title   : fill_gene_entry
 Usage   : 
 Function: This is the template method that define the skeleton of
           the method. All the method called in this method can be overriden
 Example : 
 Returns : 
 Args    : 

=cut

sub fill_gene_entry {
    my ($self,$entry_features,$chromosomeEntry,$CDS_count,$hogGenomeId)=@_;
    
    my $geneWriter     = $self->get_gene_writer;
    my $geneEntry      = $geneWriter->getNewEntry;
    my $protExtractor  = $self->get_protein_entry_extractor;
    my $protSeq;
    my $hogenom_gene_id;

    
    ## Check if CDS feat is present.
    if (!defined $entry_features->{CDS}) {
        $self->throw('No CDS features record for entry : Skip it');
    }
    
    $self->add_taxid_to_entry($geneEntry,$chromosomeEntry);
    ## Need chromosome to generate hogenom_gene_id when absent
    $self->add_chromosome_to_entry($geneEntry,$chromosomeEntry);
    # $self->add_location_to_entry();
    
    ## Need hogenom_gene_id for error message
    $self->add_hogenom_gene_id_to_entry(
        $geneEntry,
        $entry_features,
        $CDS_count,
        $hogGenomeId
    );
    
    $self->add_genomic_beg_to_entry($geneEntry,$entry_features->{CDS}); 
    $self->add_genomic_end_to_entry($geneEntry,$entry_features->{CDS});
    
    
    ## Before looking for a prot, check CDS >= 3 bp
    $self->is_CDS_length_ok($geneEntry);
    
    # if ( $self->wantProtSeq ) {
    ## Hook method
    # }

    $protSeq = $self->getProtSeq($geneEntry);
    $self->add_family_accession_to_entry($geneEntry, $entry_features, $protSeq);
    $self->add_name_to_entry($geneEntry, $entry_features);
    $self->add_locus_tag_to_entry($geneEntry, $entry_features);
    $self->add_strand_to_entry($geneEntry, $entry_features);
    $self->add_description_to_entry($geneEntry,$entry_features);

    ## Clean description
    $self->cleanDescriptionEntry($geneEntry);
    
    $protExtractor->write_entries(
        $protSeq,
        $geneWriter->getColumnValue(
            $geneEntry,
            'gene_id',
        ),
        $geneWriter->getColumnValue(
            $geneEntry,
            'hogenom_gene_id',
        ),
    );
    
    $self->set_entry_features(undef);
    return $geneEntry;

    
}


=head2 extract_taxid

 Title   : extract_taxid
 Usage   : 
 Function: 
 Example : 
 Returns : 
 Args    : 

=cut

sub extract_taxid {
    my ($self, $genome) = @_;
    
    ## Get taxid from 'source' feature (tag db_xref)
    
    my $tax_id = $genome->species->ncbi_taxid;
    if ( ! defined $tax_id) {
        $genome->throw('Didn\'t find any taxid for sequence : '.$genome->display_id);
    }
    $self->set_taxid($tax_id);
    return $tax_id;
    
    
    
    
    # my ($sourceFeat) = $genome->get_SeqFeatures('source');
    # if ( $sourceFeat->has_tag('db_xref') ) {
    #     my @db_xrefs = $sourceFeat->get_tag_values('db_xref');
    #     foreach my $db_xref ( @db_xrefs ) {
    #         if ( $db_xref =~ /^taxon:.*/ ) {
    #             $taxid = ( split( /:/,$db_xref ) )[1];
    #             last;
    #         }
    #     }
    #     $sourceFeat->throw('Didn\'t find any taxid for sequence : '.$genome->display_id) if !defined $taxid;
    # }
    # else {
    #     $taxid = 1;
    # }
    # $self->set_taxid($taxid);
    # return $taxid;
}

=head2 extract_chromosome

 Title   : extract_chromosome
 Usage   : 
 Function: 
 Example : 
 Returns : 
 Args    : 

=cut

sub extract_chromosome{
    my ($self, $genome) = @_;
    
    ## Define genome accession number as chromosome
    my $chromosome = (defined $genome->accession_number) ? uc($genome->accession_number)
                                                      : $genome->throw('No genome accession number for => '.$genome->display_id)
                                                      ;
    $self->set_chromosome($chromosome);
    return $chromosome;
}



=head2 extract_location

 Title   : extract_location
 Usage   : 
 Function: 
 Example : 
 Returns : 
 Args    : 

=cut

sub extract_location {
    my ($self, $genome) = @_;

    my $location;
    my $organelle   = $genome->species->organelle;
    


    if ( $organelle ) {
        $location = $organelle;
    }
    else {
        foreach my $feat ( $genome->get_SeqFeatures('source') ) {
            
        SWITCH:
            {
                if ( $feat->has_tag('organelle') ) {
                    ($location) = $feat->get_tag_values('organelle');
                    last SWITCH;
                }

                if ( $feat->has_tag('plasmid') ) {
                    ($location) = $feat->get_tag_values('plasmid');
                    last SWITCH;
                }

                if ( $feat->has_tag('chromosome') ) {
                    ($location) = $feat->get_tag_values('chromosome');
                    
                    if ( $location =~ /(linear|circular)/gi) {
                        undef $location;
                    }
                    elsif ( $location !~ /chromosome/gi) {
                        $location = 'chromosome '.$location
                    } 
                    last SWITCH;
                }
            }
        }
    }
    ## If still not defined, go to the description to get info.
    if ( !defined $location) {
        my $description = $genome->description;

        if ( $description =~ /chromosome\s+(\w+)/ig) {
            $location = $1;
        }
    }
    if ( defined $location) {
        $self->set_location($location);
        
    }
    else {
        Log::Log4perl->get_logger->warn(
            'No location for chromosome: '.$self->get_chromosome);
        

    }
    return $location;
    
}



=head2 get_Features

 Title   : get_Features
 Usage   : 
 Function: 
 Example : 
 Returns : 
 Args    : 

=cut

sub get_Features {
    my ($self) = @_;
    $self->throw_not_implemented();
}




=head2 is_feat_current_entry

 Title   : is_feat_current_entry
 Usage   : 
 Function: 
 Example : 
 Returns : 
 Args    : 

=cut

sub is_feat_current_entry {
    my ($self, $feat, $recording_entry_feat) = @_;

    # return 1 if !defined $self->get_entry_features;
    
    if ( $recording_entry_feat || !exists $self->get_starting_entry_feat->{$feat->primary_tag}) {
        return 1;
    }
    else {
        return 0;
        
    }
}



=head2 check_recording_state

 Title   : check_recording_state
 Usage   : 
 Function: 
 Example : 
 Returns : 
 Args    : 

=cut

sub check_recording_state{
    my ($self, $feat, $recording_flag) = @_;
    
 SWITCH:
    {
        if ( $feat->primary_tag eq 'CDS' ) {
            $recording_flag = 0;
            last SWITCH;
        }
        
        if ( exists $self->get_starting_entry_feat->{$feat->primary_tag}) {
            $recording_flag = 1;
            last SWITCH;
        }
    }
    return $recording_flag;
}



=head2 add_entry_feature

 Title   : add_entry_feature
 Usage   : 
 Function: 
 Example : 
 Returns : 
 Args    : 

=cut

sub add_entry_feature {
    my ($self, $feat, $entry_features) = @_;
    if ( !defined $entry_features) {
        $entry_features = {};
    }
    $entry_features->{$feat->primary_tag} = $feat;
    return;
}





=head2 add_taxid_to_entry

 Title   : add_taxid_to_entry
 Usage   : 
 Function: 
 Example : 
 Returns : 
 Args    : 

=cut

sub add_taxid_to_entry {
    my ($self,$geneEntry,$chromosomeEntry) = @_;
    
    ## Extract the taxid from the chromosome entry
    my $tax_id = $self->get_chromosome_writer->getColumnValue(
        $chromosomeEntry,
        'tax_id'
    );
    
    # Set the taxid
    $self->get_gene_writer->setColumnValue(
        $geneEntry,
        'tax_id',
        $tax_id,
    );
    return;
}

=head2 add_chromosome_to_entry

 Title   : add_chromosome_to_entry
 Usage   : 
 Function: 
 Example : 
 Returns : 
 Args    : 

=cut

sub add_chromosome_to_entry {
    my ($self,$geneEntry,$chromosomeEntry) = @_;
    
    ## Extract the chromosome name from the chromosome entry
    my $chromosome = $self->get_chromosome_writer->getColumnValue(
        $chromosomeEntry,
        'name'
    );
    
    # Set the taxid
    $self->get_gene_writer->setColumnValue(
        $geneEntry,
        'chromosome',
        $chromosome,
    );
    
    # $self->get_gene_writer->setColumnValue(
    #     $self->get_current_entry,
    #     'chromosome',
    #     $self->get_chromosome,
    # );
    return;
}


=head2 add_location_to_entry

 Title   : add_location_to_entry
 Usage   : 
 Function: 
 Example : 
 Returns : 
 Args    : 

=cut

# sub add_location_to_entry {
#     my ($self) = @_;
#     $self->get_gene_writer->setColumnValue(
#         $self->get_current_entry,
#         'location',
#         $self->get_location,
#     );
#     return;
# }




=head2 add_genomic_beg_to_entry

 Title   : add_genomic_beg_to_entry
 Usage   : 
 Function: 
 Example : 
 Returns : 
 Args    : 

=cut

sub add_genomic_beg_to_entry {
    my ($self, $geneEntry, $cds_feat) = @_;
    
    my $geneWriter = $self->get_gene_writer;
    # my $feat = $self->get_entry_features->{CDS};
    my $genomic_beg =  $cds_feat->location->min_start
                    || $cds_feat->location->start
                    || $cds_feat->throw('No genomic_beg for '
                                            .$geneWriter->getColumnValue(
                                                $geneEntry,
                                                'hogenom_gene_id'
                                            )
                                        );
    $geneWriter->setColumnValue(
        $geneEntry,
        'genomic_beg',
        $genomic_beg,
    );
    return;
}


=head2 add_genomic_end_to_entry

 Title   : add_genomic_end_to_entry
 Usage   : 
 Function: 
 Example : 
 Returns : 
 Args    : 

=cut

sub add_genomic_end_to_entry{
    my ($self, $geneEntry, $cds_feat) = @_;
    
    my $geneWriter = $self->get_gene_writer;
    # my $cds_feat = $self->get_entry_features->{CDS};
    my $genomic_end =  $cds_feat->location->max_end
                    || $cds_feat->location->end
                    || $cds_feat->throw('No genomic_end for '
                                            .$geneWriter->getColumnValue(
                                                $geneEntry,
                                                'hogenom_gene_id'
                                            )
                                        );
    $geneWriter->setColumnValue(
        $geneEntry,
        # $self->get_current_entry,
        'genomic_end',
        $genomic_end,
    );
    return;
}



=head2 add_hogenom_gene_id_to_entry

 Title   : add_hogenom_gene_id_to_entry
 Usage   : 
 Function: 
 Example : 
 Returns : 
 Args    : 

=cut

sub add_hogenom_gene_id_to_entry{
    my ($self) = @_;
    
    $self->throw_not_implemented();
}


=head2 add_family_accession_to_entry

 Title   : add_family_accession_to_entry
 Usage   : 
 Function: 
 Example : 
 Returns : 
 Args    : 

=cut

sub add_family_accession_to_entry {
    my ($self, $geneEntry, $entry_features, $protSeq) = @_;

    my $geneWriter = $self->get_gene_writer;
    
    ## first check if can get this information from genomic features.
    foreach my $primary_tag ( ('CDS', 'gene') ) {
        if ( defined $entry_features->{$primary_tag} ) {
            my $feat = $entry_features->{$primary_tag};
            my $gene_family;
            if (  $feat->has_tag('gene_family') ) {
                $gene_family = ($feat->get_tag_values('gene_family'))[0];
                $gene_family = $self->cleanTextEntry($gene_family);
                $geneWriter->setColumnValue(
                    $geneEntry,
                    'family_accession',
                    $gene_family
                );
                return;
            }
        }
    }
    
    

    ## try to find this information in the proteic features.
    
    my $hogenom_gene_id = $geneWriter->getColumnValue(
        $geneEntry,
        'hogenom_gene_id',
        $geneWriter->getColumnValue($geneEntry, 'hogenom_gene_id'),
    );
    
    ## This information is in the protein sequences
    
    if ( defined $protSeq) {
        my $family_acc = $self->getProtFamily($protSeq);
        
        if (!defined $family_acc) {
            Log::Log4perl->get_logger->warn(
                'No family accession for CDS : '.$hogenom_gene_id
            ) if !defined $family_acc;
            
            # $self->warn('No family accession for CDS : '.$hogenom_gene_id)
            #     if !defined $family_acc;
        }
        
        $geneWriter->setColumnValue(
            $geneEntry,
            'family_accession',
            $family_acc,
        );
    }
    
    return;
}





=head2 add_name_to_entry

 Title   : add_name_to_entry
 Usage   : 
 Function: 
 Example : 
 Returns : 
 Args    : 

=cut

sub add_name_to_entry{
    my ($self) = @_;
    
    $self->throw_not_implemented();
}


=head2 add_locus_tag_to_entry

 Title   : add_locus_tag_to_entry
 Usage   : 
 Function: 
 Example : 
 Returns : 
 Args    : 

=cut

sub add_locus_tag_to_entry{
    my ($self) = @_;
    
    $self->throw_not_implemented();
}




=head2 add_strand_to_entry

 Title   : add_strand_to_entry
 Usage   : 
 Function: 
 Example : 
 Returns : 
 Args    : 

=cut

sub add_strand_to_entry{
    my ($self, $geneEntry, $entry_features) = @_;
    
    my $geneWriter    = $self->get_gene_writer;
    my $feat          = $entry_features->{CDS};
    my $hogenomGeneId = $geneWriter->getColumnValue(
        $geneEntry,
        'hogenom_gene_id'
    );
    my $strand = $feat->location->strand
        || $feat->throw('No strand for '.$hogenomGeneId);
    
    $geneWriter->setColumnValue(
        $geneEntry,
        'strand',
        $strand
    );
    return;
}

=head2 add_description_to_entry

 Title   : add_description_to_entry
 Usage   : 
 Function: 
 Example : 
 Returns : 
 Args    : 

=cut

sub add_description_to_entry{
    my ($self) = @_;
    
    $self->throw_not_implemented();
}



=head2 write_gene_entry

 Title   : write_gene_entry
 Usage   : 
 Function: 
 Example : 
 Returns : 
 Args    : 

=cut

sub write_gene_entry {
    my ($self, $geneEntry) = @_;
    
    my $geneWriter = $self->get_gene_writer;
    
    if ( defined $geneEntry ) {
        $geneWriter->writeEntry($geneEntry);
    }
    
    
    return;
}


=head2 write_adjacent_entry

 Title   : write_adjacent_entry
 Usage   : 
 Function: 
 Example : 
 Returns : 
 Args    : 

=cut

sub write_adjacent_entry{
    my ($self, $entry) = @_;

    # my $entry  = $self->get_adj_entry;
    my $writer = $self->get_adjacent_gene_writer;
    if ( defined $entry && defined $writer) {
        
    
        my $previous = $writer->getColumnValue(
            $entry,
            'geneIdA',
        );
        
        my $follow = $writer->getColumnValue(
            $entry,
            'geneIdB',
        );
        
        
        if (defined  $previous && defined $follow) {
            $writer->writeEntry($entry);
        }
    }
    
    return;
}




=head2 start_new_entry

 Title   : start_new_entry
Usage   : 
 Function: 
 Example : 
 Returns : 
 Args    : 

=cut

# sub start_new_entry {
#     my ($self) = @_;
    
#     my $geneWriter = $self->get_gene_writer;
#     ## need to start a new entry even if not written
#     $geneWriter->incrementSequenceColumn; 
#     $self->set_previous_entry($geneEntry);
#     # my %current_gene_entry   = $geneWriter->getNewEntry;
#     $self->set_current_entry($geneWriter->getNewEntry);
#     $self->set_entry_features({});
#     return;
# }

=head2 skip_entry

 Title   : skip_entry
 Usage   : 
 Function: 
 Example : 
 Returns : 
 Args    : 

=cut

sub skip_entry {
    my ($self) = @_;
    
    my $geneWriter   = $self->get_gene_writer;
    # my %current_gene_entry = $geneWriter->getNewEntry;
    $self->set_current_entry($geneWriter->getNewEntry);
    $self->set_entry_features({});
    return;
}


=head2 checkEntry

 Title   : checkEntry
 Usage   : 
 Function: 
 Example : 
 Returns : 
 Args    : 

=cut

sub checkEntry {
    my ($self, $entry) = @_;
    $self->throw('taxid not defined, entry : '.Dumper($entry)) if !defined $entry->{tax_id};
    return;
    
}


=head2 check_and_fill_previous_following

 Title   : check_and_fill_previous_following
 Usage   : 
 Function: 
 Example : 
 Returns : 
 Args    : 

=cut

sub check_and_fill_previous_following {
    my ($self, $current, $previous) = @_;
    
    my $geneWriter = $self->get_gene_writer;

    $geneWriter->setColumnValue(
        $current,
        'previous_5_gene_id',
        $previous->{gene_id},
    );
    
    ## set following_3_gene_id from %current_gene_entry
    $geneWriter->setColumnValue(
        $previous,
        'following_3_gene_id',
        $geneWriter->getColumnValue($current, 'gene_id'),
    );
    
    ## Check the values
    
    $self->throw(
        "taxid previous and current different \nprevious => "
            .Dumper($previous)
                ."\nCurrent =>".Dumper($current)
            ) if $current->{tax_id} != $previous->{tax_id};
    
    $self->throw(
        "previous_5_gene_id of current != gene_id of previous \nprevious => "
            .Dumper($previous)
                ."\nCurrent =>".Dumper($current)
            ) if $current->{previous_5_gene_id} != $previous->{gene_id};
    
    $self->throw(
        "following_3_gene_id of previous != gene_id of current \nprevious => "
            .Dumper($previous)
                ."\nCurrent =>"
                    .Dumper($current)
                ) if $current->{gene_id} != $previous->{following_3_gene_id};
    return;
}






=head2 add_cds_count

 Title   : add_cds_count
 Usage   : 
 Function: 
 Example : 
 Returns : 
 Args    : 

=cut

sub add_cds_count{
    my ($self, $cds_count) = @_;
    $self->set_cds_count($self->get_cds_count + $cds_count);
    return;
}


=head2 set_cds_count()

 Title   : set_cds_count
 Usage   : $obj->set_cds_count()
 Function: 
 Example : 
 Returns : 
 Args    : new value (a scalar or undef)

=cut

sub set_cds_count {
    my ($self, $cds_count) = @_;
    
    $self->{_cds_count} = $cds_count;
}



=head2 get_cds_count()

 Title   : get_cds_count
 Usage   : $obj->get_cds_count()
 Function: 
 Example : 
 Returns : value of cds_count (a scalar)
 Args    : 

=cut

sub get_cds_count {
    my ($self) = @_;
    
    return $self->{_cds_count};
}



=head2 get_adjacent_gene_writer()

 Title   : get_adjacent_gene_writer
 Usage   : $obj->get_adjacent_gene_writer()
 Function: 
 Example : 
 Returns : value of adjacent_gene_writer (a scalar)
 Args    : 

=cut

sub get_adjacent_gene_writer {
    my ($self) = @_;
    
    return $self->{adjacent_gene_writer};
}


=head2 set_adjacent_gene_writer()

 Title   : set_adjacent_gene_writer
 Usage   : $obj->set_adjacent_gene_writer($newvalue)
 Function: 
 Example : 
 Returns : undef
 Args    : new value (a scalar)

=cut

sub set_adjacent_gene_writer {
    my ($self, $adjacent_gene_writer) = @_;
    
    $self->{adjacent_gene_writer} = $adjacent_gene_writer;
    return;
}


=head2 set_gene_writer()

 Title   : set_gene_writer
 Usage   : $obj->set_gene_writer($newvalue)
 Function: 
 Example : 
 Returns : undef
 Args    : new value (a scalar)

=cut

sub set_gene_writer {
    my ($self, $gene_writer) = @_;
    
    $self->{gene_writer} = $gene_writer;
    return;
}

=head2 get_gene_writer()

 Title   : get_gene_writer
 Usage   : $obj->get_gene_writer()
 Function: 
 Example : 
 Returns : value of gene_writer (a scalar)
 Args    : 

=cut

sub get_gene_writer {
    my ($self) = @_;
    
    return $self->{gene_writer};
}




=head2 is_CDS_length_ok

 Title   : is_CDS_length_ok
 Usage   : 
 Function: 
 Example : 
 Returns : 
 Args    : 

=cut

sub is_CDS_length_ok {
    my ($self, $geneEntry) = @_;
    
    my $geneWriter = $self->get_gene_writer;
    my $beg = $geneWriter->getColumnValue(
        $geneEntry,
        'genomic_beg'
    );
    my $end = $geneWriter->getColumnValue(
        $geneEntry,
        'genomic_end'
    );
    my $CDS_length = $end - $beg;
    
    if ( $CDS_length <= 3 ) {
        my $hogenom_gene_id = $geneWriter->getColumnValue(
            $geneEntry,
            'hogenom_gene_id'
        );
        $self->throw(
            "CDS length too small : $hogenom_gene_id : beg = $beg, end = $end"
        );
        return 0;
    }
    return 1;
}






=head2 handleErrors

 Title   : handleErrors
 Usage   : 
 Function: 
 Example : 
 Returns : 
 Args    : 

=cut

sub handleErrors {
    my ($self, $msg, $count_CDS) = @_;

    
 SWITCH: 
    {
        if ( $msg =~ /CDS length too small/g ) {
            $msg =~ /MSG:\s+(.+)\n/;
            $msg = $1;
            $msg .= ' => skip it';
            Log::Log4perl->get_logger->warn(
                $msg.' : CDS_count = '.$self->get_cds_count.'  => skip entry'
            );
            $count_CDS++;
            $self->skip_entry($self->get_gene_writer);
            last SWITCH;
        }

        if ( $msg =~ /Cannot get the protein sequence for/g) {
            $msg =~ /MSG:\s+(.+)\n/;
            $msg = $1;
            Log::Log4perl->get_logger->warn(
                $msg.' : CDS_count = '.$self->get_cds_count.'  => skip entry'
            );
            $count_CDS++;
            $self->skip_entry($self->get_gene_writer);
            ## increment the 
            
            last SWITCH;
        }
        
        if ( $msg =~ /No strand for/g) {
            $msg =~ /MSG:\s+(.+)\n/;
            $msg = $1;
            Log::Log4perl->get_logger->warn(
                $msg.' : CDS_count = '.$self->get_cds_count.'  => skip entry'
            );
            $count_CDS++;
            $self->skip_entry($self->get_gene_writer);
            last SWITCH;
        }


        if ( $msg =~ /No CDS features record for entry/g) {
            $msg =~ /MSG:\s+(.+)\n/;
            $msg = $1;
            Log::Log4perl->get_logger->warn(
                $msg.' : CDS_count = '.$self->get_cds_count.'  => skip entry'
            );
            $count_CDS++;
            $self->skip_entry($self->get_gene_writer);
            last SWITCH;
        }

        
        
        $self->throw($msg);
        
        
        $msg =~ /MSG:\s+(.+)\n/;
        $msg = $1;
        Log::Log4perl->get_logger->error(
            '"'.$msg.'" : CDS_count = '.$self->get_cds_count.'  => skip entry default'
        );
        
    }
    
    return $count_CDS;
    
}

=head2 get_protein_idx()

 Title   : get_protein_idx
 Usage   : $obj->get_protein_idx()
 Function: 
 Example : 
 Returns : value of protein_idx (a scalar)
 Args    : 

=cut

sub get_protein_idx {
    my ($self) = @_;

    return $self->{_protein_idx};
}


=head2 set_protein_idx()

 Title   : set_protein_idx
 Usage   : $obj->set_protein_idx()
 Function: 
 Example : 
 Returns : 
 Args    : new value (a scalar or undef)

=cut

sub set_protein_idx {
    my ($self, $protein_idx) = @_;
    
    $self->{_protein_idx} = $protein_idx;
}



=head2 set_chromosome()

 Title   : set_chromosome
 Usage   : $obj->set_chromosome()
 Function: 
 Example : 
 Returns : 
 Args    : new value (a scalar or undef)

=cut

sub set_chromosome {
    my ($self, $chromosome) = @_;
    
    $self->{_chromosome} = $chromosome;
}


=head2 get_chromosome()

 Title   : get_chromosome
 Usage   : $obj->get_chromosome()
 Function: 
 Example : 
 Returns : value of chromosome (a scalar)
 Args    : 

=cut

sub get_chromosome {
    my ($self) = @_;
    
    return $self->{_chromosome};
}


=head2 set_location()

 Title   : set_location
 Usage   : $obj->set_location($newvalue)
 Function: 
 Example : 
 Returns : undef
 Args    : new value (a scalar)

=cut

sub set_location {
    my ($self, $location) = @_;
    
    $self->{location} = $location;
    return;
}


=head2 get_location()

 Title   : get_location
 Usage   : $obj->get_location()
 Function: 
 Example : 
 Returns : value of location (a scalar)
 Args    : 

=cut

sub get_location {
    my ($self) = @_;
    
    return $self->{location};
}




=head2 set_current_entry()

 Title   : set_current_entry
 Usage   : $obj->set_current_entry()
 Function: 
 Example : 
 Returns : 
 Args    : new value (a scalar or undef)

=cut

sub set_current_entry {
    my ($self, $current_entry) = @_;
    
    $self->{_current_entry} = $current_entry;
}


=head2 get_current_entry()

 Title   : get_current_entry
 Usage   : $obj->get_current_entry()
 Function: 
 Example : 
 Returns : value of current_entry (a scalar)
 Args    : 

=cut

sub get_current_entry {
    my ($self) = @_;
    
    return $self->{_current_entry};
}



=head2 set_previous_entry()

 Title   : set_previous_entry
 Usage   : $obj->set_previous_entry()
 Function: 
 Example : 
 Returns : 
 Args    : new value (a scalar or undef)

=cut

sub set_previous_entry {
    my ($self, $previous_entry) = @_;
    
    $self->{_previous_entry} = $previous_entry;
}


=head2 get_previous_entry()

 Title   : get_previous_entry
 Usage   : $obj->get_previous_entry()
 Function: 
 Example : 
 Returns : value of previous_entry (a scalar)
 Args    : 

=cut

sub get_previous_entry {
    my ($self) = @_;
    
    return $self->{_previous_entry};
}


=head2 set_adj_entry()

 Title   : set_adj_entry
 Usage   : $obj->set_adj_entry($newvalue)
 Function: 
 Example : 
 Returns : undef
 Args    : new value (a scalar)

=cut

sub set_adj_entry {
    my ($self, $adj_entry) = @_;
    
    $self->{adj_entry} = $adj_entry;
    return;
}



=head2 get_adj_entry()

 Title   : get_adj_entry
 Usage   : $obj->get_adj_entry()
 Function: 
 Example : 
 Returns : value of adj_entry (a scalar)
 Args    : 

=cut

sub get_adj_entry {
    my ($self) = @_;
    
    return $self->{adj_entry};
}




=head2 set_taxid()

 Title   : set_taxid
 Usage   : $obj->set_taxid()
 Function: 
 Example : 
 Returns : 
 Args    : new value (a scalar or undef)

=cut

sub set_taxid {
    my ($self, $taxid) = @_;
    
    $self->{_taxid} = $taxid;
}

=head2 get_taxid()

 Title   : get_taxid
 Usage   : $obj->get_taxid()
 Function: 
 Example : 
 Returns : value of taxid (a scalar)
 Args    : 

=cut

sub get_taxid {
    my ($self) = @_;
    
    return $self->{_taxid};
}



=head2 set_entry_features()

 Title   : set_entry_features
 Usage   : $obj->set_entry_features()
 Function: 
 Example : 
 Returns : 
 Args    : new value (a scalar or undef)

=cut

sub set_entry_features {
    my ($self, $entry_features) = @_;
    
    $self->{_entry_features} = $entry_features;
}



=head2 get_entry_features()

 Title   : get_entry_features
 Usage   : $obj->get_entry_features()
 Function: 
 Example : 
 Returns : value of entry_features (a scalar)
 Args    : 

=cut

sub get_entry_features {
    my ($self) = @_;
    
    return $self->{_entry_features};
}


=head2 set_taxids()

 Title   : set_taxids
 Usage   : $obj->set_taxids($newvalue)
 Function: 
 Example : 
 Returns : undef
 Args    : new value (a scalar)

=cut

sub set_taxids {
    my ($self, $taxids) = @_;
    
    $self->{taxids} = $taxids;
    return;
}


=head2 get_taxids()

 Title   : get_taxids
 Usage   : $obj->get_taxids()
 Function: 
 Example : 
 Returns : value of taxids (a scalar)
 Args    : 

=cut

sub get_taxids {
    my ($self) = @_;
    
    return $self->{taxids};
}

=head2 hasToExtractTaxid

 Title   : hasToExtractTaxid
 Usage   : 
 Function: 
 Example : 
 Returns : 
 Args    : 

=cut

sub hasToExtractTaxid{
    my ($self,$taxid) = @_;

    if ( defined $self->get_taxids && !defined $self->get_taxids->{$taxid}) {
        return 0;
    }
    return 1;
}




=head2 getProtSeq

 Title   : getProtSeq
 Usage   : 
 Function: 
 Example : 
 Returns : 
 Args    : 

=cut

sub getProtSeq {
    my ($self, $geneEntry) = @_;

    my $geneWriter = $self->get_gene_writer;
    my $cds_id = $geneWriter->getColumnValue(
        $geneEntry,
        # $self->get_current_entry,
        'hogenom_gene_id'
    );
    
    $cds_id =~ s/(.*)\./$1_/o;
    
    my $protSeq = $self->get_protein_idx->get_Seq_by_id($cds_id);
    
    if ( !defined $protSeq ) {
        (my $new_cds = $cds_id) =~ s/_PE\d+//g;
        Log::Log4perl->get_logger->warn(
            "Didn't find a prot for $cds_id => try with $new_cds"
        );

        $protSeq = $self->get_protein_idx->get_Seq_by_id($new_cds);
        
        if ( !defined $protSeq || !$protSeq->isa('Bio::Seq::RichSeqI') ) {
            $self->throw("Cannot get the protein sequence for $new_cds");
        }
        else {
            $geneWriter->setColumnValue(
                $geneEntry,
                'hogenom_gene_id',
                $new_cds,
            );
        }
    }
    return $protSeq;
}


=head2 getProtFamily

 Title   : getProtFamily
 Usage   : 
 Function: 
 Example : 
 Returns : 
 Args    : 

=cut

sub getProtFamily {
    my ($self, $protSeq) = @_;
    foreach my $comment ( $protSeq->annotation->get_Annotations('comment') ) {
        $comment->text =~ /-\!-\s+GENE_FAMILY:\s+(\w+)/g;
        my $family_acc = $1;
        
        #my $family_acc =~ s/^HBG/HOG/g;
        
        return $family_acc;
    }
}


=head2 get_starting_entry_feat()

 Title   : get_starting_entry_feat
 Usage   : $obj->get_starting_entry_feat()
 Function: 
 Example : 
 Returns : value of starting_entry_feat (a scalar)
 Args    : 

=cut

sub get_starting_entry_feat {
    my ($self) = @_;
    
    return $self->{_starting_entry_feat};
}


=head2 get_protein_entry_extractor()

 Title   : get_protein_entry_extractor
 Usage   : $obj->get_protein_entry_extractor()
 Function: 
 Example : 
 Returns : value of protein_entry_extractor (a scalar)
 Args    : 

=cut

sub get_protein_entry_extractor {
    my ($self) = @_;
    
    return $self->{protein_entry_extractor};
}


=head2 set_protein_entry_extractor()

 Title   : set_protein_entry_extractor
 Usage   : $obj->set_protein_entry_extractor($newvalue)
 Function: 
 Example : 
 Returns : undef
 Args    : new value (a scalar)

=cut

sub set_protein_entry_extractor {
    my ($self, $protein_entry_extractor) = @_;
    
    $self->{protein_entry_extractor} = $protein_entry_extractor;
    return;
}





=head2 set_starting_entry_feat()

 Title   : set_starting_entry_feat
 Usage   : $obj->set_starting_entry_feat()
 Function: 
 Example : 
 Returns : 
 Args    : new value (a scalar or undef)

=cut

sub set_starting_entry_feat {
    my ($self, $starting_entry_feat) = @_;
    
    $self->{_starting_entry_feat} = $starting_entry_feat;
}



=head2 set_chromosome_writer()

 Title   : set_chromosome_writer
 Usage   : $obj->set_chromosome_writer($newvalue)
 Function: 
 Example : 
 Returns : undef
 Args    : new value (a scalar)

=cut

sub set_chromosome_writer {
    my ($self, $chromosome_writer) = @_;
    
    $self->{chromosome_writer} = $chromosome_writer;
    return;
}

=head2 get_chromosome_writer()

 Title   : get_chromosome_writer
 Usage   : $obj->get_chromosome_writer()
 Function: 
 Example : 
 Returns : value of chromosome_writer (a scalar)
 Args    : 

=cut

sub get_chromosome_writer {
    my ($self) = @_;
    
    return $self->{chromosome_writer};
}




=head2 check_or_fill_hogenom_gene_id

 Title   : check_or_fill_hogenom_gene_id
 Usage   : 
 Function: 
 Example : 
 Returns : 
 Args    : 

=cut

sub check_or_fill_hogenom_gene_id {
    my ($self, $entry, $CDS_count, $hogGenomeId, $hogenom_gene_id_extracted) = @_;
    
    my $geneWriter  = $self->get_gene_writer;
    my $generated_gene_id = uc($hogGenomeId).'.PE'.$CDS_count;
    
    if ( defined $hogenom_gene_id_extracted ) {
        # if ( $hogenom_gene_id_extracted ne $generated_gene_id) {
        #     $self->throw(
        #         "Generated hogenom_gene_id : $generated_gene_id <> "
        #             ."$hogenom_gene_id_extracted"
        #     );
        # }
        $geneWriter->setColumnValue(
            $entry,
            'hogenom_gene_id',
            $hogenom_gene_id_extracted,
        );
    }
    else {
        $geneWriter->setColumnValue(
            $entry,
            'hogenom_gene_id',
            $generated_gene_id,
        );
    }
    
    # if ( !defined $geneWriter->getColumnValue($entry, 'hogenom_gene_id') ) {
    # }
    return;
}


=head2 wantProtSeq

 Title   : wantProtSeq
 Usage   : 
 Function: 
 Example : 
 Returns : 
 Args    : 

=cut

sub wantProtSeq {
    my ($self) = @_;
    return 0;
}



=head2 cleanTextEntry

 Title   : cleanTextEntry
 Usage   : 
 Function: 
 Example : 
 Returns : 
 Args    : 

=cut

sub cleanTextEntry{
    my ($self, $txt) = @_;
    
    $txt =~ s/\t+/ /g;
    $txt =~ s/\|/_/g;
    $txt =~ s/\s*\(\d+\s+of\s+\d+\)\s*$//g;
   
    
    return $txt;
}


=head2 cleanDescriptionEntry

 Title   : cleanDescriptionEntry
 Usage   : 
 Function: 
 Example : 
 Returns : 
 Args    : 

=cut

sub cleanDescriptionEntry {
    my ($self,$entry) = @_;
    
    my $geneWriter = $self->get_gene_writer;
    my $desc = $geneWriter->getColumnValue(
        $entry,
        'description',
    );
    my $hogenomGeneId = $geneWriter->getColumnValue(
        $entry,
        'hogenom_gene_id',
    );


    my $hogenomGeneIdQuoted = quotemeta($hogenomGeneId);
    
    $desc =~ s/(Sub|Rec)Name: Full=//g;
    # print STDERR $hogenomGeneIdQuoted,"\n" if ($hogenomGeneIdQuoted =~ /\(|\)/);
    
    $desc =~ s{\s*\(\s*$hogenomGeneIdQuoted\s*\)\.*}{}g;

    $desc =~ s{\||\\}{}g;
    
    $geneWriter->setColumnValue(
        $entry,
        'description',
        $desc,
    );
    return;
    
}



## Warn Function when problems

=head2 tupleNotFound

 Title   : tupleNotFound
 Usage   : 
 Function: 
 Example : 
 Returns : 
 Args    : 

=cut

sub tupleNotFound{
    my ($self, $entry, $column) = @_;
    my $geneWriter = $self->get_gene_writer;
    
    Log::Log4perl->get_logger->warn(
        "$column not found for : " 
            .$geneWriter->getColumnValue(
                $entry,
                'hogenom_gene_id'
            )
        );
    return;
}


1;
