# $Id$
#
# BioPerl module for Bio::DB::Populate::TableEntryWriter
#
# Please direct questions and support issues to <bioperl-l@bioperl.org>
#
# Cared for by Remi Planel <remi.planel@univ-lyon1.fr>
#
# Copyright Remi Planel
#
# You may distribute this module under the same terms as perl itself

# POD documentation - main docs before the code

=head1 NAME

Bio::DB::Populate::TableEntryWriter - DESCRIPTION of Object

=head1 SYNOPSIS

Give standard usage here

=head1 DESCRIPTION

Describe the object here

=head1 FEEDBACK

=head2 Mailing Lists

User feedback is an integral part of the evolution of this and other
Bioperl modules. Send your comments and suggestions preferably to
the Bioperl mailing list.  Your participation is much appreciated.

  bioperl-l@bioperl.org                  - General discussion
http://bioperl.org/wiki/Mailing_lists  - About the mailing lists

=head2 Support

Please direct usage questions or support issues to the mailing list:

L<bioperl-l@bioperl.org>

rather than to the module maintainer directly. Many experienced and
reponsive experts will be able look at the problem and quickly
address it. Please include a thorough description of the problem
with code and data examples if at all possible.

=head2 Reporting Bugs

Report bugs to the Bioperl bug tracking system to help us keep track
of the bugs and their resolution. Bug reports can be submitted via
the web:

  http://bugzilla.open-bio.org/

=head1 AUTHOR - Remi Planel

Email remi.planel@univ-lyon1.fr

Describe contact details here

=head1 CONTRIBUTORS

Additional contributors names and emails here

=head1 APPENDIX

The rest of the documentation details each of the object methods.
Internal methods are usually preceded with a _

=cut

# Let the code begin...



package Bio::DB::Populate::TableEntryWriter;
use strict;
use Data::Dumper;
# Object preamble - inherits from Bio::Root::Root

use Bio::Root::Root;


use base qw(Bio::Root::Root );



=head2 new

 Title   : new
 Usage   : my $obj = Bio::DB::Populate::TableEntryWriter->new(
                            -file           => $outputFileName,
                            -column_def     => [
                                 'column1',
                                 'column2',
                                 'column3',
                            ],
                            -auto_increment => 'column1',

                     );
 Function: Builds a new Bio::DB::Populate::TableEntryWriter object
 Returns : an instance of Bio::DB::Populate::TableEntryWriter
 Args    : -file           : filename where the entries will be write.
           -column_def     : Defintion of the columns
           -auto_increment : define a column that need to be automatically incremented (usually the primary key) 

=cut



sub new {
    my ($class,@args) = @_;
    
    my $self = $class->SUPER::new(@args);
    my (
        $file,
        $columnDef,
        $autoIncrement,
        $auto_increment_start,
        $nullchar,
    ) = $self->_rearrange(
        [qw(
               FILE
               COLUMN_DEF
               AUTO_INCREMENT
               AUTO_INCREMENT_START
               NULLCHAR
               
       )],
        @args
    );
    $self->set_nullchar($nullchar || '\N');
    $self->{_file} = $file      || $self->throw("You must define an output file");
    $self->{_columnDef} = $columnDef || $self->throw("You must define the tables's column");
    $self->{_auto_increment} = $autoIncrement;
    open (my $FH,'>',$self->getFile)
        or die ("Cannot open file : ".$self->getFile."\nERROR : $!");
    $self->{_fh} = $FH;
    $self->_initEntry($auto_increment_start);
    
    return $self;
}

=head2 _initEntry

 Title   : _initEntry
 Usage   : 
 Function: PRIVATE method that initialize the object
           => Shouldn't be used directly
 Example : 
 Returns : 
 Args    :

=cut

sub _initEntry {
    my ($self, $auto_increment_starting_value) = @_;
    
    my %entryHash = map { $_ => undef} @{$self->{_columnDef}};
    if ( defined $self->{_auto_increment} ) {
        $auto_increment_starting_value = 1 if !defined $auto_increment_starting_value;
        $entryHash{ $self->{_auto_increment} } = $auto_increment_starting_value;
    }
    $self->{_entry}  = \%entryHash;
    return;
}


=head2 getNewEntry

 Title   : getNewEntry
 Usage   : $tableEntryWriter->getNewEntry
 Function: return the current entry of $tableEntryWriter
 Example : 
 Returns : a ref to an hash
 Args    : 

=cut

sub getNewEntry {
    my ($self) = @_;
    
    return {%{$self->{_entry}}};
}


=head2 getFile

 Title   : getFile
 Usage   : $tableEntryWriter->getFile
 Function: return the path to the file where the entries are saved
 Example : 
 Returns : scalar : path to the file
 Args    : 

=cut

sub getFile {
    my ($self) = @_;
    
    return $self->{_file};
}

=head2 getFH

 Title   : getFH
 Usage   : $tableEntryWriter->getFH
 Function: return the filehandler of the open output file
 Example : 
 Returns : 
 Args    : 

=cut

sub getFH {
    my ($self) = @_;
    return $self->{_fh};
}



=head2 setColumnValue

 Title   : setColumnValue
 Usage   : $tableEntryWriter->setColumnValue
 Function: Set the value for a specific column.
              -The column must be defined in the column definition
              -Throw an exception if column not defined
 Example : 
 Returns : 
 Args    : 

=cut

sub setColumnValue {
    my ($self, $entry, $col, $val) = @_;
    $entry->{$col} = (exists $entry->{$col}) ? $val
                                             : $self->throw( 'The column '
                                               .$col
                                               .' does not exist')
                                             ;
    return;
}


=head2 getColumnValue

 Title   : getColumnValue
 Usage   : $tableEntryWriter->getColumnValue
 Function: return the value for a specific column.
              -The column must be defined in the column definition
              -Throw an exception if column not defined
 Example : 
 Returns : a scalar 
 Args    : name of the column

=cut

sub getColumnValue {
    my ($self, $entry, $col) = @_;

    return (exists $entry->{$col}) ? $entry->{$col}
                                   : $self->throw( 'The column '
                                    .$col
                                    .' does not exist')
                                   ;
}



=head2 getColumnDef

 Title   : getColumnDef
 Usage   : $tableEntryWriter->getColumnDef
 Function: return the definition of the column
 Example : 
 Returns : the array ref pass to the constructor : column_def => ['id','name']
 Args    : 

=cut

sub getColumnDef {
    my ($self) = @_;

    return $self->{_columnDef};
}



=head2 get_nullchar()

 Title   : get_nullchar
 Usage   : $obj->get_nullchar()
 Function: 
 Example : 
 Returns : value of nullchar (a scalar)
 Args    : 

=cut

sub get_nullchar {
    my ($self) = @_;
    
    return $self->{_nullchar};
}



=head2 set_nullchar()

 Title   : set_nullchar
 Usage   : $obj->set_nullchar()
 Function: 
 Example : 
 Returns : 
 Args    : new value (a scalar or undef)

=cut

sub set_nullchar {
    my ($self, $nullchar) = @_;
    
    $self->{_nullchar} = $nullchar;
}




=head2 incrementSequenceColumn 

 Title   : incrementSequenceColumn 
 Usage   : $tableEntryWriter->incrementSequenceColumn
 Function: start a new entry : 1. increment the auto_increment column
                               2. clean all the other column (set to null)
 Example : 
 Returns : 
 Args    : 

=cut

sub incrementSequenceColumn {
    my ($self) = @_;
    if (defined $self->{_auto_increment}) {
        $self->{_entry}->{ $self->{_auto_increment} }++;
    }
   return; 
}




=head2 writeEntry

 Title   : writeEntry
 Usage   : $tableEntryWriter->writeEntry
 Function: write the entry to the file.
           Then start a new entry => 1. increment the auto_increment column
                                     2. clean all the other column (set to null)
 Example : 
 Returns : 
 Args    : 

=cut

sub writeEntry {
    my ($self, $entry) = @_;
    my $buf = '';
    my $count = 0;
    my $i;
    my $delimiter = '|';
    


    
    
    ## Last element need a special behavior
    ## Don't want to put a test in the loop
    ## => Let the last element be processed outside of the loop
    for ( $i=0; $i < scalar(@{ $self->getColumnDef })-1; $i++ ) {
        if ( defined $entry->{ $self->getColumnDef->[$i] } ) {
            $buf .= $entry->{ $self->getColumnDef->[$i] }.$delimiter;
        }
        else {
            $buf .= $self->get_nullchar.$delimiter;
        }
    }

    if ( defined $entry->{ $self->getColumnDef->[$i] }) {
        $buf .= $entry->{ $self->getColumnDef->[$i] }."\n";
    }
    else {
        $buf .= $self->get_nullchar."\n";
    }

    $| =1;
    # print "is writing entry\n";
    # print $buf;

    print {$self->getFH} $buf;
    $self->incrementSequenceColumn;
    
}

=head2 clean_entry

 Title   : clean_entry
 Usage   : 
 Function: 
 Example : 
 Returns : 
 Args    : 

=cut

sub clean_entry{
    my ($self, $entry) = @_;
    my %entry = $self->getNewEntry;
    $entry = \%entry;
    return;
}




1;
