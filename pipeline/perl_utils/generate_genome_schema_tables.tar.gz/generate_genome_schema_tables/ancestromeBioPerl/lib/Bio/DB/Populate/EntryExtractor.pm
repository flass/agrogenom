# $Id$
#
# BioPerl module for Bio::DB::Populate::EntryExtractor
#
# Please direct questions and support issues to <bioperl-l@bioperl.org>
#
# Cared for by Remi Planel <remi.planel@univ-lyon1.fr>
#
# Copyright Remi Planel
#
# You may distribute this module under the same terms as perl itself

# POD documentation - main docs before the code

=head1 NAME

Bio::DB::Populate::EntryExtractor - DESCRIPTION of Object

=head1 SYNOPSIS

Give standard usage here

=head1 DESCRIPTION

Describe the object here

=head1 FEEDBACK

=head2 Mailing Lists

User feedback is an integral part of the evolution of this and other
Bioperl modules. Send your comments and suggestions preferably to
the Bioperl mailing list.  Your participation is much appreciated.

  bioperl-l@bioperl.org                  - General discussion
http://bioperl.org/wiki/Mailing_lists  - About the mailing lists

=head2 Support

Please direct usage questions or support issues to the mailing list:

L<bioperl-l@bioperl.org>

rather than to the module maintainer directly. Many experienced and
reponsive experts will be able look at the problem and quickly
address it. Please include a thorough description of the problem
with code and data examples if at all possible.

=head2 Reporting Bugs

Report bugs to the Bioperl bug tracking system to help us keep track
of the bugs and their resolution. Bug reports can be submitted via
the web:

  http://bugzilla.open-bio.org/

=head1 AUTHOR - Remi Planel

Email remi.planel@univ-lyon1.fr

Describe contact details here

=head1 CONTRIBUTORS

Additional contributors names and emails here

=head1 APPENDIX

The rest of the documentation details each of the object methods.
Internal methods are usually preceded with a _

=cut

# Let the code begin...


package Bio::DB::Populate::EntryExtractor;
use strict;

# Object preamble - inherits from Bio::Root::Root

use Bio::Root::Root;


use base qw(Bio::Root::Root );

=head2 new

 Title   : new
 Usage   : my $obj = new Bio::DB::Populate::EntryExtractor();
 Function: Builds a new Bio::DB::Populate::EntryExtractor object
 Returns : an instance of Bio::DB::Populate::EntryExtractor
 Args    :

=cut

sub new {
    my ($class,@args) = @_;
    
    my $self = $class->SUPER::new(@args);

    my ($logger) = $self->_rearrange([qw(LOGGER)],@args);
    

    $self->set_logger($logger);
    
    
    return $self;
}


=head2 get_tableEntryWriter()

 Title   : get_tableEntryWriter
 Usage   : $obj->get_tableEntryWriter()
 Function: 
 Example : 
 Returns : value of tableEntryWriter (a scalar)
 Args    : 

=cut

sub get_tableEntryWriter {
    my ($self) = @_;
    
    return $self->{_tableEntryWriter};
}


=head2 set_tableEntryWriter()

 Title   : set_tableEntryWriter
 Usage   : $obj->set_tableEntryWriter()
 Function: 
 Example : 
 Returns : 
 Args    : new value (a scalar or undef)

=cut

sub set_tableEntryWriter {
    my ($self, $tableEntryWriter) = @_;

    if ( defined $tableEntryWriter && $tableEntryWriter->isa('Bio::DB::Populate::TableEntryWriter') ) {
        $self->{_tableEntryWriter} = $tableEntryWriter;
    }
    else {
        $self->throw(
            'tableEntryWriter must be defined and a Bio::DB::Populate::TableEntryWriter object'
        );
        
    }
    return;
}



=head2 write_entries

 Title   : write_entries
 Usage   : 
 Function: 
 Example : 
 Returns : 
 Args    : 

=cut

sub write_entries{
    my ($self) = @_;
    
    $self->throw_not_implemented();
}


=head2 set_logger()

 Title   : set_logger
 Usage   : $obj->set_logger($newvalue)
 Function: 
 Example : 
 Returns : undef
 Args    : new value (a scalar)

=cut

sub set_logger {
    my ($self, $logger) = @_;
    
    $self->{logger} = $logger;
    return;
}


=head2 get_logger()

 Title   : get_logger
 Usage   : $obj->get_logger()
 Function: 
 Example : 
 Returns : value of logger (a scalar)
 Args    : 

=cut

sub get_logger {
    my ($self) = @_;
    
    return $self->{logger};
}



=head2 cleanDescriptionEntry

 Title   : cleanDescriptionEntry
 Usage   : 
 Function: 
 Example : 
 Returns : 
 Args    : 

=cut

sub cleanDescriptionEntry {
    my ($self,$entry) = @_;
    
    my $geneWriter = $self->get_gene_writer;
    my $desc = $geneWriter->getColumnValue(
        $entry,
        'description',
    );
    my $hogenomGeneId = $geneWriter->getColumnValue(
        $entry,
        'hogenom_gene_id',
    );

    
    my $hogenomGeneIdQuoted = quotemeta($hogenomGeneId);
    
    $desc =~ s/(Sub|Rec)Name: Full=//g;
    # print STDERR $hogenomGeneIdQuoted,"\n" if ($hogenomGeneIdQuoted =~ /\(|\)/);
    
    $desc =~ s{\s*\(\s*$hogenomGeneIdQuoted\s*\)\.*}{}g;

    $desc =~ s{\||\\}{}g;
    
    $geneWriter->setColumnValue(
        $entry,
        'description',
        $desc,
    );
    return;
    
}




1;
