# $Id$
#
# BioPerl module for Bio::DB::Populate::EntryExtractor::ProteinEntryExtractor
#
# Please direct questions and support issues to <bioperl-l@bioperl.org>
#
# Cared for by Remi Planel <remi.planel@univ-lyon1.fr>
#
# Copyright Remi Planel
#
# You may distribute this module under the same terms as perl itself

# POD documentation - main docs before the code

=head1 NAME

Bio::DB::Populate::EntryExtractor::ProteinEntryExtractor - DESCRIPTION of Object

=head1 SYNOPSIS

Give standard usage here

=head1 DESCRIPTION

Describe the object here

=head1 FEEDBACK

=head2 Mailing Lists

User feedback is an integral part of the evolution of this and other
Bioperl modules. Send your comments and suggestions preferably to
the Bioperl mailing list.  Your participation is much appreciated.

  bioperl-l@bioperl.org                  - General discussion
http://bioperl.org/wiki/Mailing_lists  - About the mailing lists

=head2 Support

Please direct usage questions or support issues to the mailing list:

L<bioperl-l@bioperl.org>

rather than to the module maintainer directly. Many experienced and
reponsive experts will be able look at the problem and quickly
address it. Please include a thorough description of the problem
with code and data examples if at all possible.

=head2 Reporting Bugs

Report bugs to the Bioperl bug tracking system to help us keep track
of the bugs and their resolution. Bug reports can be submitted via
the web:

  http://bugzilla.open-bio.org/

=head1 AUTHOR - Remi Planel

Email remi.planel@univ-lyon1.fr

Describe contact details here

=head1 CONTRIBUTORS

Additional contributors names and emails here

=head1 APPENDIX

The rest of the documentation details each of the object methods.
Internal methods are usually preceded with a _

=cut

# Let the code begin...


package Bio::DB::Populate::EntryExtractor::ProteinEntryExtractor;
use strict;

# Object preamble - inherits from Bio::Root::Root

use Bio::Root::Root;
use Data::Dumper;


use base qw(Bio::DB::Populate::EntryExtractor);

=head2 new

 Title   : new
 Usage   : my $obj = new Bio::DB::Populate::EntryExtractor::ProteinEntryExtractor();
 Function: Builds a new Bio::DB::Populate::EntryExtractor::ProteinEntryExtractor object
 Returns : an instance of Bio::DB::Populate::EntryExtractor::ProteinEntryExtractor
 Args    :

=cut

sub new {
    my ($class,@args) = @_;
    
    my $self = $class->SUPER::new(@args);
    
    
    my (
        $protein_idx,
        $auto_increment_start,
        $output,
    ) = $self->_rearrange(
        [qw(
               PROTEIN_IDX
               AUTO_INCREMENT_START
               OUTPUT
       )],
        @args,
    );
    
    
    my $proteinTable = Bio::DB::Populate::TableEntryWriter->new(
        -file                 => $output.'/protein_table.csv',
        -column_def           => [
            'protein_id',
            'gene_id',
            'length',
            'description',
            'hogenom_protein_id',
        ],
        -auto_increment       => 'protein_id',
        -auto_increment_start => $auto_increment_start,
    );

    my $prot_go = Bio::DB::Populate::TableEntryWriter->new(
        -file                 => $output.'/protein_go_table.csv',
        -column_def           => [
            'protein_id',
            'go_id',
        ],
    );


    my $prot_dbxref = Bio::DB::Populate::TableEntryWriter->new(
        -file                 => $output.'/protein_dbxref_table.csv',
        -column_def           => [
            'protein_id',
            'db_id',
            'accession',
        ],
    );


    my $dbxref = Bio::DB::Populate::TableEntryWriter->new(
        -file                 => $output.'/dbxref_table.csv',
        -column_def           => [
            'db_id',
            'name',
            'uri',
        ],
        -auto_increment       => 'db_id',
        -auto_increment_start => $auto_increment_start,
    );
    

    $self->{xref_db} = {};
    # $self->{xref_db_id} = 1;
    
    
    
    $self->set_protein_go_table_writer($prot_go);
    $self->set_protein_dbxref_table_writer($prot_dbxref);
    $self->set_protein_idx($protein_idx);
    $self->set_tableEntryWriter($proteinTable);
    $self->set_dbxref_table_writer($dbxref);
    
    
    return $self;
}



=head2 write_entries

 Title   : write_entries
 Usage   : 
 Function: 
 Example : 
 Returns : 
 Args    : 

=cut

sub write_entries {
    my ($self, $prot, $gene_id, $hogenomGeneId) = @_;

    ## Prot table
    my $proteinId;
    my $tableEntryWriter = $self->get_tableEntryWriter;
    my $protEntry        = $tableEntryWriter->getNewEntry;
    ## go_prot table
    my $goEntryWriter    = $self->get_protein_go_table_writer;
    my $goEntry          = $goEntryWriter->getNewEntry;
    ## prot_dbxref table
    my $protDbxrefEntryWriter = $self->get_protein_dbxref_table_writer;
    my $protDbxrefEntry       = $protDbxrefEntryWriter->getNewEntry;



    #############################
    # Add protein to prot table #
    #############################
    
    $tableEntryWriter->setColumnValue(
        $protEntry,
        'gene_id',
        $gene_id,
    );
    

    $tableEntryWriter->setColumnValue(
        $protEntry,
        'hogenom_protein_id',
        $prot->id,
    );
    
    $tableEntryWriter->setColumnValue(
        $protEntry,
        'length',
        $prot->length,
    );


    $tableEntryWriter->setColumnValue(
        $protEntry,
        'description',
        $prot->description,
    );


    
    
    $self->cleanDescriptionEntry($protEntry, $hogenomGeneId);
    
    $tableEntryWriter->writeEntry($protEntry);
    # $tableEntryWriter->incrementSequenceColumn;

    $proteinId = $tableEntryWriter->getColumnValue(
        $protEntry,
        'protein_id',
    );
    

    # print STDERR $hogenomGeneId,"\n";
    # exit;
    
    # $|=1;

    
    # print Dumper $prot->annotation->get_Annotations("dblink");
    
    
    foreach my $dblink ( $prot->annotation->get_Annotations("dblink")) {
        my $dbName    = $dblink->database;
        my $accession = $dblink->primary_id;
        
        
    SWITCH: 
        {
            if ($dbName eq 'UniProtKB/Swiss-Prot' || $dbName eq 'RefSeq'
                    || $dbName eq 'ProDom') {
                
                $self->addXrefDb($dbName);
                $protDbxrefEntryWriter->setColumnValue(
                    $protDbxrefEntry,
                    'protein_id',
                    $proteinId,
                );

                # print $self->getXrefDbId($dbName),"\n";
                
                
                $protDbxrefEntryWriter->setColumnValue(
                    $protDbxrefEntry,
                    'db_id',
                    $self->getXrefDbId($dbName),
                );
                
                $protDbxrefEntryWriter->setColumnValue(
                    $protDbxrefEntry,
                    'accession',
                    $accession,
                );
                $protDbxrefEntryWriter->writeEntry($protDbxrefEntry);
                $protDbxrefEntry = $protDbxrefEntryWriter->getNewEntry;
                
                last SWITCH;
            }
            if ( $dbName eq 'GO' ) {

                $self->addXrefDb($dbName);
                        
                
                $goEntryWriter->setColumnValue(
                    $goEntry,
                    'protein_id',
                    $proteinId,
                );
                $goEntryWriter->setColumnValue(
                    $goEntry,
                    'go_id',
                    $accession,
                );
            
                $goEntryWriter->writeEntry($goEntry);
                $goEntry = $goEntryWriter->getNewEntry;
                
                last SWITCH;
                
            }

        }
        
    }
    # die;
    
    
    
    # print Dumper $self->{xref_db};
    
    
    
    
    
    return;
    
    
}

=head2 cleanDescriptionEntry

 Title   : cleanDescriptionEntry
 Usage   : 
 Function: 
 Example : 
 Returns : 
 Args    : 

=cut

sub cleanDescriptionEntry {
    my ($self,$entry, $hogenomProtId) = @_;
    
    my $tableEntryWriter = $self->get_tableEntryWriter;
    my $desc = $tableEntryWriter->getColumnValue(
        $entry,
        'description',
    );
    

    my $hogenomProtIdQuoted = quotemeta($hogenomProtId);
    
    
    $desc =~ s/(Sub|Rec)Name: Full=//g;

    $desc =~ s{\s*\(\s*$hogenomProtIdQuoted\s*\)\.*}{}g;

    $desc =~ s{\||\\}{}g;
    
    $tableEntryWriter->setColumnValue(
        $entry,
        'description',
        $desc,
    );
    return;
}




=head2 get_protein_idx()

 Title   : get_protein_idx
 Usage   : $obj->get_protein_idx()
 Function: 
 Example : 
 Returns : value of protein_idx (a scalar)
 Args    : 

=cut

sub get_protein_idx {
    my ($self) = @_;

    return $self->{_protein_idx};
}


=head2 set_protein_idx()

 Title   : set_protein_idx
 Usage   : $obj->set_protein_idx()
 Function: 
 Example : 
 Returns : 
 Args    : new value (a scalar or undef)

=cut

sub set_protein_idx {
    my ($self, $protein_idx) = @_;
    
    $self->{_protein_idx} = $protein_idx;
}


=head2 set_protein_go_table_writer()

 Title   : set_protein_go_table_writer
 Usage   : $obj->set_protein_go_table_writer($newvalue)
 Function: 
 Example : 
 Returns : undef
 Args    : new value (a scalar)

=cut

sub set_protein_go_table_writer {
    my ($self, $protein_go_table_writer) = @_;
    
    $self->{protein_go_table_writer} = $protein_go_table_writer;
    return;
}

=head2 get_protein_go_table_writer()

 Title   : get_protein_go_table_writer
 Usage   : $obj->get_protein_go_table_writer()
 Function: 
 Example : 
 Returns : value of protein_go_table_writer (a scalar)
 Args    : 

=cut

sub get_protein_go_table_writer {
    my ($self) = @_;
    
    return $self->{protein_go_table_writer};
}


=head2 set_protein_dbxref_table_writer()

 Title   : set_protein_dbxref_table_writer
 Usage   : $obj->set_protein_dbxref_table_writer($newvalue)
 Function: 
 Example : 
 Returns : undef
 Args    : new value (a scalar)

=cut

sub set_protein_dbxref_table_writer {
    my ($self, $protein_dbxref_table_writer) = @_;
    
    $self->{protein_dbxref_table_writer} = $protein_dbxref_table_writer;
    return;
}


=head2 get_protein_dbxref_table_writer()

 Title   : get_protein_dbxref_table_writer
 Usage   : $obj->get_protein_dbxref_table_writer()
 Function: 
 Example : 
 Returns : value of protein_dbxref_table_writer (a scalar)
 Args    : 

=cut

sub get_protein_dbxref_table_writer {
    my ($self) = @_;
    
    return $self->{protein_dbxref_table_writer};
}



=head2 set_dbxref_table_writer()

 Title   : set_dbxref_table_writer
 Usage   : $obj->set_dbxref_table_writer($newvalue)
 Function: 
 Example : 
 Returns : undef
 Args    : new value (a scalar)

=cut

sub set_dbxref_table_writer {
    my ($self, $dbxref_table_writer) = @_;
    
    $self->{dbxref_table_writer} = $dbxref_table_writer;
    return;
}

=head2 get_dbxref_table_writer()

 Title   : get_dbxref_table_writer
 Usage   : $obj->get_dbxref_table_writer()
 Function: 
 Example : 
 Returns : value of dbxref_table_writer (a scalar)
 Args    : 

=cut

sub get_dbxref_table_writer {
    my ($self) = @_;
    
    return $self->{dbxref_table_writer};
}




=head2 addXrefDb

 Title   : addXrefDb
 Usage   : 
 Function: 
 Example : 
 Returns : 
 Args    : 

=cut

sub addXrefDb{
    my ($self,$dbName) = @_;

    if ( !exists $self->{xref_db}->{$dbName} ) {
        my $writer = $self->get_dbxref_table_writer();
        my $entry  = $writer->getNewEntry;
                
        $self->{xref_db}->{$dbName} = $writer->getColumnValue(
            $entry,
            'db_id',
        );
        $writer->setColumnValue(
            $entry,
            'name',
            $dbName,
        );
        $writer->writeEntry($entry);
        # $writer->incrementSequenceColumn;
    }
    return $self->{xref_db}->{$dbName};
}


=head2 getXrefDbId

 Title   : getXrefDbId
 Usage   : 
 Function: 
 Example : 
 Returns : 
 Args    : 

=cut

sub getXrefDbId{
    my ($self, $dbName) = @_;
    return $self->{xref_db}->{$dbName};
    
}




1;
