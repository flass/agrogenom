# $Id$
#
# BioPerl module for Bio::DB::Populate::EntryExtractor::GeneEntryExtractor::Ensembl
#
# Please direct questions and support issues to <bioperl-l@bioperl.org>
#
# Cared for by Remi Planel <remi.planel@univ-lyon1.fr>
#
# Copyright Remi Planel
#
# You may distribute this module under the same terms as perl itself

# POD documentation - main docs before the code

=head1 NAME

Bio::DB::Populate::EntryExtractor::GeneEntryExtractor::Ensembl - DESCRIPTION of Object

=head1 SYNOPSIS

Give standard usage here

=head1 DESCRIPTION

Describe the object here

=head1 FEEDBACK

=head2 Mailing Lists

User feedback is an integral part of the evolution of this and other
Bioperl modules. Send your comments and suggestions preferably to
the Bioperl mailing list.  Your participation is much appreciated.

  bioperl-l@bioperl.org                  - General discussion
http://bioperl.org/wiki/Mailing_lists  - About the mailing lists

=head2 Support

Please direct usage questions or support issues to the mailing list:

L<bioperl-l@bioperl.org>

rather than to the module maintainer directly. Many experienced and
reponsive experts will be able look at the problem and quickly
address it. Please include a thorough description of the problem
with code and data examples if at all possible.

=head2 Reporting Bugs

Report bugs to the Bioperl bug tracking system to help us keep track
of the bugs and their resolution. Bug reports can be submitted via
the web:

  http://bugzilla.open-bio.org/

=head1 AUTHOR - Remi Planel

Email remi.planel@univ-lyon1.fr

Describe contact details here

=head1 CONTRIBUTORS

Additional contributors names and emails here

=head1 APPENDIX

The rest of the documentation details each of the object methods.
Internal methods are usually preceded with a _

=cut

# Let the code begin...


package Bio::DB::Populate::EntryExtractor::GeneEntryExtractor::Ensembl;
use strict;
use Data::Dumper;

# Object preamble - inherits from Bio::Root::Root

use Bio::Root::Root;


use base qw(Bio::DB::Populate::EntryExtractor::GeneEntryExtractor );

=head2 new

 Title   : new
 Usage   : my $obj = new Bio::DB::Populate::EntryExtractor::GeneEntryExtractor::Ensembl();
 Function: Builds a new Bio::DB::Populate::EntryExtractor::GeneEntryExtractor::Ensembl object
 Returns : an instance of Bio::DB::Populate::EntryExtractor::GeneEntryExtractor::Ensembl
 Args    :

=cut

sub new {
    my ($class,@args) = @_;
    
    my $self = $class->SUPER::new(@args);

    $self->set_starting_entry_feat(
        {
            'CDS'    => undef,
            'gene'   => undef,
            '5\'ncr' => undef,
        }
    );
    
    return $self;
}




=head2 get_Features

 Title   : get_Features
 Usage   : 
 Function: 
 Example : 
 Returns : 
 Args    : 

=cut

sub get_Features{
    my ($self, $seq) = @_;
    
    ## Loop through feature 'CDS'
    # my @features = $genome->get_SeqFeatures('CDS');
    
    ## does what get_SeqFeatures('CDS') do but can had several condition
    my @features = map {
        (
            $_->primary_tag eq 'CDS'
             || $_->primary_tag eq '5\'ncr'
             || $_->primary_tag eq '3\'ncr'
             || $_->primary_tag eq 'gene'
             || $_->primary_tag eq 'int_int'
         ) ? $_ : () } @{$seq->{'_as_feat'}};

    return \@features;
}



=head2 add_hogenom_gene_id_to_entry

 Title   : add_hogenom_gene_id_to_entry
 Usage   : 
 Function: 
 Example : 
 Returns : 
 Args    : 

=cut

sub add_hogenom_gene_id_to_entry {
    my ($self, $geneEntry, $entry_features, $CDS_count, $hogGenomeId) = @_;
    
    my $geneWriter = $self->get_gene_writer;
    my $hogenom_gene_id;
    
    foreach my $primary_tag ( ('5\'ncr', '3\'ncr', 'int_int') ) {
        if ( defined $entry_features->{$primary_tag} ) {
            my $feat = $entry_features->{$primary_tag};
            if ( $feat->has_tag('cds_name')) {
                $hogenom_gene_id = ($feat->get_tag_values('cds_name'))[0];
                $hogenom_gene_id =~ s/^\s+//;
                $hogenom_gene_id =~ s/\s+$//;
                last;
            }
        }
    }
    
    $self->check_or_fill_hogenom_gene_id(
        $geneEntry,
        ## increment since $CDS_count is the number of written entry => so +1 for this one
        $CDS_count, 
        $hogGenomeId,
        $hogenom_gene_id,
    );
    return;
}


=head2 wantProtSeq

 Title   : wantProtSeq
 Usage   : 
 Function: 
 Example : 
 Returns : 
 Args    : 

=cut

sub wantProtSeq {
    my ($self) = @_;
    return 1;
    
}




=head2 add_name_to_entry

 Title   : add_name_to_entry
 Usage   : 
 Function: 
 Example : 
 Returns : 
 Args    : 

=cut

sub add_name_to_entry {
    my ($self, $geneEntry, $entry_features) = @_;

    my $geneWriter = $self->get_gene_writer;
    
    foreach my $primary_tag ( ('CDS', 'gene') ) {
        if ( defined $entry_features->{$primary_tag} ) {
            my $feat = $entry_features->{$primary_tag};
            
            my $gene_name;
            if (  $feat->has_tag('gene') ) {
                $gene_name = ($feat->get_tag_values('gene'))[0];
                $gene_name = $self->cleanTextEntry($gene_name);
                ## Fill the entry with the extracted gene name
                $geneWriter->setColumnValue(
                    $geneEntry,
                    'name',
                    $gene_name
                );
                return;
            }
        }
    }
    ## If here, gene name not found.
    $self->tupleNotFound($geneEntry,'Gene name');
    return;
}


=head2 add_locus_tag_to_entry

 Title   : add_locus_tag_to_entry
 Usage   : 
 Function: 
 Example : 
 Returns : 
 Args    : 

=cut

sub add_locus_tag_to_entry {
    my ($self, $geneEntry, $entry_features) = @_;

    my $geneWriter = $self->get_gene_writer;
    
    foreach my $primary_tag ( ('CDS', 'gene') ) {
        if ( defined $entry_features->{$primary_tag} ) {
            my $feat = $entry_features->{$primary_tag};
            
            my $gene_locus_tag;
            if (  $feat->has_tag('locus_tag') ) {
                $gene_locus_tag = ($feat->get_tag_values('locus_tag'))[0];
                $gene_locus_tag = $self->cleanTextEntry($gene_locus_tag);
                ## Fill the entry with the extracted locus tag
                $geneWriter->setColumnValue(
                    $geneEntry,
                    'locus_tag',
                    $gene_locus_tag
                );
                return;
            }
        }
    }
    ## If here, locus tag not found
    $self->tupleNotFound($geneEntry,'Locus tag');
    return;
}



=head2 add_description_to_entry

 Title   : add_description_to_entry
 Usage   : 
 Function: 
 Example : 
 Returns : 
 Args    : 

=cut

sub add_description_to_entry {
    my ($self, $geneEntry,$entry_features) = @_;
    
    my $geneWriter = $self->get_gene_writer;
    my $description;
    
    foreach my $primary_tag ( ('gene', 'CDS') ) {
        if ( defined $entry_features->{$primary_tag} ) {
            my $feat = $entry_features->{$primary_tag};
            
            if (  $feat->has_tag('product') ) {
                $description = ($feat->get_tag_values('product'))[0];
                last;
            }
            
            
            if (  $feat->has_tag('note') ) {
                $description = ($feat->get_tag_values('note'))[0];
                last;
            }
            
            
            if (  $feat->has_tag('function') ) {
                $description = join(" ; ",$feat->get_tag_values('function'));
                last;
            }

            if (  $feat->has_tag('biological_process') ) {
                $description = join(" ; ",$feat->get_tag_values('biological_process'));
                last;
            }
        }
    }
    
    if ( defined $description ) {
        $description = $self->cleanTextEntry($description);
        $geneWriter->setColumnValue(
            $geneEntry,
            'description',
            $description,
        );
    }
    else {
        $self->tupleNotFound($geneEntry,'Description');
    }
    return;
}





1;
