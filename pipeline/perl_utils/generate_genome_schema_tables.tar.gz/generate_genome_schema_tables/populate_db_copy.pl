#!/usr/bin/env perl
# populate_db_copy.pl --- blabla
# Author: Remi Planel <rplanel@univ-lyon1.fr>
# Created: 05 Dec 2011
# Version: 0.01

use warnings;
use strict;

use Getopt::Long;
use Pod::Usage;
use Data::Dumper;
use FindBin qw($Bin);
use lib "$Bin/ancestromeBioPerl/lib";

# use lib "$Bin/../../../../../lib";
use File::Basename;
use Log::Log4perl qw(:easy);




## BioPerl module
use Bio::SeqIO;
use Bio::Index::Swissprot; ## indexing protein file

## App specific
use Bio::DB::Populate::TableEntryWriter;
use Bio::DB::Populate::EntryExtractor::GeneEntryExtractor::Ebi;
use Bio::DB::Populate::EntryExtractor::GeneEntryExtractor::Agrogenom;
use Bio::DB::Populate::EntryExtractor::GeneEntryExtractor::Greview;
use Bio::DB::Populate::EntryExtractor::GeneEntryExtractor::Ensembl;





my (
    $genome_dir,
    $genome,
    $format,
    $source,
    $protein_file,
    $listTaxid,
    $auto_increment_start,
    $output_dir,
    $help,$man
);

GetOptions(
    'genome_dir|gd=s'           => \$genome_dir,
    'genome|g=s'                => \$genome,
    'format|f:s'                => \$format,
    'source|s=s'           => \$source, #$SOURCE4FILE{$g_file}
    'protein|p=s'          => \$protein_file,
    'auto_increment_start|id=i' => \$auto_increment_start,
    'output|out|o=s'            => \$output_dir,
    'list_taxid|lt:s'           => \$listTaxid,
    'help|?'                    => \$help,
    'man'                       => \$man,
) or pod2usage(2);
pod2usage(1) if $help;
pod2usage(-exitstatus => 0, -verbose => 2) if $man;


$format = 'embl' if !defined $format;


# Log::Log4perl->easy_init($ERROR);




#####################################
## Check protein file and index it ##
#####################################

my $protein_indexed_file;
my $protein_idx;
my $gene_id = 1;
my $CDS_count = 0;
my @genome_paths;
my $geneEntryExtractor;
my $taxidToExtract;


if ( defined $protein_file) {
    $protein_indexed_file = $protein_file.'.idx';

    if ( -e $protein_indexed_file ) {
        $protein_idx = Bio::Index::Swissprot->new(
            -filename   => $protein_indexed_file,
            -write_flag => 0,
        );
    
    } else {

        print "Creating an index file for proteins\n";
    
        $protein_idx = Bio::Index::Swissprot->new(
            -filename   => $protein_indexed_file,
            -write_flag => 1,
        );
        ## code used to parse the ID for record from a string.
        ## return the value that will be used to query the indexed file.
        my $id_parser = sub {
            my $line = shift;
            if ($line =~ /^ID\s*(\S+)/) {
                return $1;
            }
        };
        $protein_idx->id_parser($id_parser);
        $protein_idx->make_index($protein_file);
    }
}
# exit;


## get the taxid we want to extract in an hash table
if ( defined $listTaxid && -f $listTaxid) {
    
    open(my $LIST_TAXID, '<', "$listTaxid") || die("Cannot open file $listTaxid\nError: $!\n");
    
    while ( my $l = <$LIST_TAXID>) {
        chomp $l;
        $taxidToExtract->{$l}++;
    }
}

if ( defined $genome_dir) {
    my $GENOME_DIR;
    $genome_dir =~ s/\/$//; ## Remove trailing '/'
    opendir($GENOME_DIR, $genome_dir) || die("Cannot open dir $genome_dir => ERROR: $!\n");
    @genome_paths =   map  { "$genome_dir".'/'."$_"            }
                      grep { /.*\.dat/ && -f "$genome_dir/$_" }
                         readdir($GENOME_DIR);
}


if ( defined $genome) {
    push(@genome_paths,$genome);
}



printf("## %-30s | %-20s | %-20s | %-20s|\n",'File','source module','CDS per file', 'CDS Total');
print '-' x 103;print "\n";



foreach my $genome_path ( @genome_paths ) {

    my $GENOME_IN;

    if ($genome_path =~ /\.gz$/) {
        open($GENOME_IN, "gunzip -c $genome_path |")
            || die "can't open pipe to $genome_path";
    }
    else {
        open($GENOME_IN,'<',$genome_path) || die "can't open $genome_path";
    }
    
    my ($g_file, $g_dir) = fileparse($genome_path);
    my $CDS_per_file = 0;
    my $genomeIn = Bio::SeqIO->new(
        -fh => $GENOME_IN,
        # -file   => $genome_path,
        -format => $format,
        -verbose => 2,
    );
    
    
    Log::Log4perl->easy_init(
        {
            level => $DEBUG,
            file  => "> $output_dir/$g_file.log",
        },
    );
    
    my @constructorParameter = (
        -protein_idx          => $protein_idx,
        -auto_increment_start => $auto_increment_start,
        -output               => $output_dir,
        -taxids               => $taxidToExtract,
    );
    

 SWITCH: 
    {


        if ( !defined $source) {
            die('No source defined. type "populate_db_copy.pl -h" to get the help');
            last SWITCH;
            
        }


        
        if ( $source eq 'ensembl' ) {
            
            $geneEntryExtractor =
                Bio::DB::Populate::EntryExtractor::GeneEntryExtractor::Ensembl->new(
                    @constructorParameter
                );
            
            last SWITCH;
        }

        if ( $source eq 'ebi' ) {
            $geneEntryExtractor = Bio::DB::Populate::EntryExtractor::GeneEntryExtractor::Ebi->new(
                @constructorParameter
            );
            last SWITCH;
        }

        if ( $source eq 'agrogenom') {
            $geneEntryExtractor = Bio::DB::Populate::EntryExtractor::GeneEntryExtractor::Agrogenom->new(
                @constructorParameter
            );
            last SWITCH;
        }

        if ( $source eq 'greview') {
            $geneEntryExtractor = Bio::DB::Populate::EntryExtractor::GeneEntryExtractor::Greview->new(
                @constructorParameter
            );
            last SWITCH;
        }
        
        
        die("No source defined for the file : $g_file"); 
        
    }
    
    
    $|=1;
    printf("## %-30s | %-20s | ",$g_file,$source);
    
    ## Suppose to be faster but it might work only with genbank format
    my $builder = $genomeIn->sequence_builder();
    $builder->want_all(1);
    $builder->add_unwanted_slot('seq','annotation');
    
    while ( my $genome = $genomeIn->next_seq ) {
        $CDS_per_file += $geneEntryExtractor->write_entries($genome);
    }
    $CDS_count += $CDS_per_file;
    printf("%-20d | %-20d|\n",$CDS_per_file, $CDS_count);
}



__END__

=head1 NAME

populate_db_copy.pl

=head1 SYNOPSIS

populate_db_copy.pl [options] args

      -g   --genome        Complete genome file (embl format).
      -s   --source        The source of the complete genome file [agrogenom|ensembl|ebi|greview].
      -p   --protein       Proteome file (swiss format).
      -id                  Gene primary key starting value.
      -o                   Output dir where all the database raw files will be saved
      -h                   Display this help

=head1 DESCRIPTION

Stub documentation for populate_gene_table.pl, 

=head1 AUTHOR

Remi Planel, E<lt>rplanel@umr5558-rplanel.univ-lyon1.frE<gt>

=head1 COPYRIGHT AND LICENSE

Copyright (C) 2011 by Remi Planel

This program is free software; you can redistribute it and/or modify
it under the same terms as Perl itself, either Perl version 5.8.2 or,
at your option, any later version of Perl 5 you may have available.

=head1 BUGS

None reported... yet.

=cut
